
import { UserStats, GraphData, ChatMessage, SavedImage, Note } from '../types';

const STORAGE_KEYS = {
  STATS: 'synapse_user_stats',
  GRAPH: 'synapse_neuro_map',
  CHAT: 'synapse_nexus_chat_history',
  GALLERY: 'synapse_vision_gallery',
  NOTES: 'synapse_idea_vault'
};

const DEFAULT_STATS: UserStats = {
  sessionsCompleted: 0,
  nodesExplored: 0,
  minutesDebated: 0,
  quizScore: 0,
  weeklyActivity: [
    { day: 'Mon', value: 0 },
    { day: 'Tue', value: 0 },
    { day: 'Wed', value: 0 },
    { day: 'Thu', value: 0 },
    { day: 'Fri', value: 0 },
    { day: 'Sat', value: 0 },
    { day: 'Sun', value: 0 },
  ],
  level: 1,
  title: "Novice Explorer"
};

const DEFAULT_GRAPH: GraphData = {
  nodes: [],
  links: []
};

// --- Core Storage Functions ---

export const getStats = (): UserStats => {
  const stored = localStorage.getItem(STORAGE_KEYS.STATS);
  return stored ? JSON.parse(stored) : DEFAULT_STATS;
};

export const saveStats = (stats: UserStats) => {
  localStorage.setItem(STORAGE_KEYS.STATS, JSON.stringify(stats));
};

export const getGraphData = (): GraphData => {
  const stored = localStorage.getItem(STORAGE_KEYS.GRAPH);
  return stored ? JSON.parse(stored) : DEFAULT_GRAPH;
};

export const saveGraphData = (data: GraphData) => {
  localStorage.setItem(STORAGE_KEYS.GRAPH, JSON.stringify(data));
};

// --- Chat Persistence ---

export const getChatHistory = (): ChatMessage[] => {
    try {
        const stored = localStorage.getItem(STORAGE_KEYS.CHAT);
        return stored ? JSON.parse(stored) : [];
    } catch (e) {
        return [];
    }
};

export const saveChatHistory = (messages: ChatMessage[]) => {
    // Keep only last 50 messages to prevent storage bloat
    const trimmed = messages.slice(-50); 
    localStorage.setItem(STORAGE_KEYS.CHAT, JSON.stringify(trimmed));
};

export const clearChatHistory = () => {
    localStorage.removeItem(STORAGE_KEYS.CHAT);
};

// --- Vision Gallery Persistence ---

export const getImageGallery = (): SavedImage[] => {
    try {
        const stored = localStorage.getItem(STORAGE_KEYS.GALLERY);
        return stored ? JSON.parse(stored) : [];
    } catch (e) {
        return [];
    }
};

export const saveGeneratedImage = (image: SavedImage) => {
    try {
        const current = getImageGallery();
        // LIFO: Add new to top
        const updated = [image, ...current];
        
        // Quota Management: Keep max 20 images to prevent QuotaExceededError
        if (updated.length > 20) {
            updated.length = 20; 
        }
        
        localStorage.setItem(STORAGE_KEYS.GALLERY, JSON.stringify(updated));
    } catch (e) {
        console.error("Storage full, could not save image", e);
    }
};

export const deleteImageFromGallery = (id: string) => {
    const current = getImageGallery();
    const updated = current.filter(img => img.id !== id);
    localStorage.setItem(STORAGE_KEYS.GALLERY, JSON.stringify(updated));
};

// --- Idea Vault Persistence ---

export const getNotes = (): Note[] => {
    try {
        const stored = localStorage.getItem(STORAGE_KEYS.NOTES);
        return stored ? JSON.parse(stored) : [];
    } catch (e) {
        return [];
    }
};

export const saveNote = (note: Note) => {
    try {
        const current = getNotes();
        const existingIndex = current.findIndex(n => n.id === note.id);
        let updated;
        if (existingIndex >= 0) {
            updated = [...current];
            updated[existingIndex] = note;
        } else {
            updated = [note, ...current];
        }
        localStorage.setItem(STORAGE_KEYS.NOTES, JSON.stringify(updated));
    } catch (e) {
        console.error("Failed to save note", e);
    }
};

export const deleteNote = (id: string) => {
    const current = getNotes();
    const updated = current.filter(n => n.id !== id);
    localStorage.setItem(STORAGE_KEYS.NOTES, JSON.stringify(updated));
};

export const resetData = () => {
  localStorage.clear();
  window.location.reload();
};

// --- Analysis & Recalculation Engine ---

export const calculateLevel = (stats: UserStats): UserStats => {
  const { nodesExplored, quizScore, minutesDebated } = stats;
  
  // Custom algorithm to determine "Intellect Level"
  // 1 Node = 10pts, 1 Minute = 5pts, Quiz Score is raw
  const totalXP = (nodesExplored * 10) + (minutesDebated * 5) + quizScore;
  
  let newLevel = 1;
  let newTitle = "Novice Explorer";

  if (totalXP > 500) { newLevel = 2; newTitle = "Data Weaver"; }
  if (totalXP > 1500) { newLevel = 3; newTitle = "Logic Architect"; }
  if (totalXP > 3000) { newLevel = 4; newTitle = "Quantum Thinker"; }
  if (totalXP > 5000) { newLevel = 5; newTitle = "Synaptic Master"; }
  if (totalXP > 10000) { newLevel = 6; newTitle = "Omniscient"; }

  return {
    ...stats,
    level: newLevel,
    title: newTitle
  };
};

export const updateActivity = (currentStats: UserStats, activityValue: number): UserStats => {
    const today = new Date().toLocaleDateString('en-US', { weekday: 'short' });
    const newActivity = currentStats.weeklyActivity.map(day => {
        if (day.day === today) {
            return { ...day, value: day.value + activityValue };
        }
        return day;
    });
    return { ...currentStats, weeklyActivity: newActivity };
};

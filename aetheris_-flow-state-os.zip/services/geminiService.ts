
import { GoogleGenAI, Type, LiveServerMessage, Modality } from "@google/genai";
import { GraphData, QuizQuestion, LanguageCode, ChatMessage, LearningModule, ChatSource, MathTopic, MathConcept, SkillChallenge, SkillEvaluation } from "../types";
import { LANGUAGE_PROMPT_NAMES } from "../constants";

// Helper to ensure API key presence
const getAIClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found in environment");
  }
  return new GoogleGenAI({ apiKey });
};

// Helper to extract YouTube ID (Improved Regex)
const getYouTubeId = (url: string) => {
    // Matches standard, short, embed, and mobile urls
    const regExp = /^.*(?:(?:youtu\.be\/|v\/|vi\/|u\/\w\/|embed\/|shorts\/)|(?:(?:watch)?\?v(?:i)?=|\&v(?:i)?=))([^#\&\?]*).*/;
    const match = url.match(regExp);
    // ID is usually 11 chars
    return (match && match[1].length === 11) ? match[1] : null;
};

// --- NeuroMap Service ---
export const generateConceptMap = async (topic: string, existingNodes: string[] = [], language: LanguageCode = 'en'): Promise<GraphData> => {
  const ai = getAIClient();
  
  const isExpansion = existingNodes.length > 0;
  const targetLang = LANGUAGE_PROMPT_NAMES[language] || 'English';
  
  const prompt = isExpansion 
    ? `TASK: Expand knowledge graph node "${topic}".
       CONTEXT: Existing nodes: ${existingNodes.join(', ')}.
       OUTPUT_LANGUAGE: ${targetLang} (Must be ${targetLang}).
       ACTION: Identify 4 distinct sub-concepts.
       CONSTRAINT: Descriptions must be under 6 words. Return JSON.`
    : `TASK: Create knowledge graph for "${topic}".
       OUTPUT_LANGUAGE: ${targetLang} (Must be ${targetLang}).
       ACTION: Create main node + 5 sub-concepts.
       CONSTRAINT: Descriptions must be under 6 words. Return JSON.`;

  const schemaProp = {
    nodes: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING },
          group: { type: Type.INTEGER },
          val: { type: Type.INTEGER },
          desc: { type: Type.STRING, description: "Max 6 words" }
        }
      }
    },
    links: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          source: { type: Type.STRING },
          target: { type: Type.STRING }
        }
      }
    }
  };

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: schemaProp
      }
    }
  });

  if (response.text) {
    return JSON.parse(response.text) as GraphData;
  }
  throw new Error("Failed to generate graph data");
};

// --- Quantum Quiz Service ---
export const generateQuiz = async (topic: string, language: LanguageCode = 'en'): Promise<QuizQuestion[]> => {
    const ai = getAIClient();
    const targetLang = LANGUAGE_PROMPT_NAMES[language] || 'English';
    
    // Updated to 10 questions
    const prompt = `Create 10 multiple-choice questions about "${topic}".
    LANGUAGE: Output strictly in ${targetLang}.
    CONSTRAINTS: 
    - Explanation max 15 words.
    - Hint max 5 words.
    - Return JSON.`;

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.ARRAY,
                items: {
                    type: Type.OBJECT,
                    properties: {
                        id: { type: Type.STRING },
                        question: { type: Type.STRING },
                        options: { type: Type.ARRAY, items: { type: Type.STRING } },
                        correctIndex: { type: Type.INTEGER },
                        explanation: { type: Type.STRING },
                        hint: { type: Type.STRING }
                    }
                }
            }
        }
    });

    if (response.text) {
        return JSON.parse(response.text) as QuizQuestion[];
    }
    return [];
};

// --- VisionLab Service (Image Gen) ---
export const generateMetaphorImage = async (
    concept: string, 
    language: LanguageCode = 'en', 
    style: string = 'cinematic',
    modelId: string = 'gemini-2.5-flash-image'
): Promise<{ imageUrl: string, explanation: string }> => {
  const ai = getAIClient();
  const targetLang = LANGUAGE_PROMPT_NAMES[language] || 'English';
  
  const textResponse = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: `Explain "${concept}" with a visual metaphor.
    OUTPUT 1: English Prompt for Image Gen (Style: ${style}).
    OUTPUT 2: Explanation in ${targetLang}.
    Format: "PROMPT: <english_text> | EXPLANATION: <translated_text>"`,
  });
  
  const text = textResponse.text || "";
  const parts = text.split('|');
  const metaphorPrompt = parts[0]?.replace('PROMPT:', '').trim() || concept;
  const explanation = parts[1]?.replace('EXPLANATION:', '').trim() || metaphorPrompt;

  const imageResponse = await ai.models.generateContent({
    model: modelId,
    contents: {
      parts: [
        { text: `${style} style: ${metaphorPrompt}. High quality, detailed.` }
      ]
    },
    config: {
        imageConfig: {
            aspectRatio: "1:1",
        }
    }
  });

  let imageUrl = "";
  for (const part of imageResponse.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
          imageUrl = `data:image/png;base64,${part.inlineData.data}`;
      }
  }

  if (!imageUrl) throw new Error("Image generation returned no data");

  return {
    imageUrl,
    explanation
  };
};

// --- Idea Vault Service ---
export const refineNote = async (content: string, language: LanguageCode = 'en'): Promise<string> => {
    const ai = getAIClient();
    const targetLang = LANGUAGE_PROMPT_NAMES[language] || 'English';

    const prompt = `Refine and expand the following idea to be more clear, structured, and insightful.
    Language: ${targetLang}
    Input: "${content}"`;

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt
    });

    return response.text || content;
};

// --- Nexus Chat Service ---
export const sendChatMessage = async (
    history: ChatMessage[], 
    newMessage: string, 
    language: LanguageCode = 'en',
    options: { webSearch: boolean, deepThink: boolean, modelId: string } = { webSearch: false, deepThink: false, modelId: 'gemini-2.5-flash' }
): Promise<{ text: string, sources?: ChatSource[] }> => {
    const ai = getAIClient();
    const targetLang = LANGUAGE_PROMPT_NAMES[language] || 'English';

    const context = history.map(m => `${m.role === 'user' ? 'User' : 'AI'}: ${m.text}`).join('\n');
    
    let model = options.modelId;
    if (options.deepThink) {
        model = "gemini-3-pro-preview"; 
    }

    const tools: any[] = [];
    if (options.webSearch) {
        tools.push({ googleSearch: {} });
    }

    const prompt = `System: You are Nexus, the AI companion in the Aetheris app. 
    Language: Answer strictly in ${targetLang}. 
    Style: ${options.deepThink ? "Detailed, logical, step-by-step reasoning." : "Concise, futuristic, helpful."}
    
    Conversation History:
    ${context}
    
    User: ${newMessage}
    AI:`;

    const response = await ai.models.generateContent({
        model: model,
        contents: prompt,
        config: {
            tools: tools.length > 0 ? tools : undefined
        }
    });

    const text = response.text || "Connection interrupted.";
    let sources: ChatSource[] = [];

    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (chunks) {
        chunks.forEach((chunk: any) => {
            if (chunk.web?.uri && chunk.web?.title) {
                sources.push({
                    title: chunk.web.title,
                    uri: chunk.web.uri
                });
            }
        });
    }

    return { text, sources };
};

// --- Cosmos Learn Service (Updated for Real Links) ---
export const generateLearningPlan = async (topic: string, language: LanguageCode = 'en'): Promise<LearningModule[]> => {
    const ai = getAIClient();
    const targetLang = LANGUAGE_PROMPT_NAMES[language] || 'English';

    // Strict prompt to ensure we get valid YT links
    const prompt = `
    Role: Educational Curator.
    Task: Find 5 BEST YouTube tutorials for "${topic}".
    Language: Title/Desc in ${targetLang}.
    
    CRITICAL REQUIREMENT:
    - Return a JSON array.
    - "videoUrl" MUST be a valid, standard YouTube link (e.g., https://www.youtube.com/watch?v=VIDEO_ID).
    - Do NOT use shortened URLs if possible.
    
    JSON Fields: title, channelName, description (max 10 words), videoUrl, duration.
    `;

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash", 
        contents: prompt,
        config: {
            tools: [{ googleSearch: {} }] 
        }
    });

    const text = response.text || "";
    const jsonStr = text.replace(/```json|```/g, '').trim();
    
    try {
        const rawData = JSON.parse(jsonStr);
        
        return rawData.map((item: any, index: number) => {
            const videoId = getYouTubeId(item.videoUrl) || "";
            // Use 'hqdefault' for better quality than 'mqdefault'
            const thumbnail = videoId ? `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg` : `https://placehold.co/640x360/1e293b/FFF?text=${encodeURIComponent(topic)}`;
            
            return {
                id: (Date.now() + index).toString(),
                title: item.title,
                channelName: item.channelName || "YouTube",
                description: item.description,
                videoUrl: item.videoUrl,
                thumbnail: thumbnail,
                duration: item.duration || "10 min"
            } as LearningModule;
        });
    } catch (e) {
        console.error("Failed to parse learning plan JSON", e);
        return [];
    }
};

// --- Infinity Math Service ---

export const generateMathRoadmap = async (level: string, language: LanguageCode = 'en'): Promise<MathTopic[]> => {
    const ai = getAIClient();
    const targetLang = LANGUAGE_PROMPT_NAMES[language] || 'English';

    const prompt = `Generate a structured math learning roadmap for a ${level} level student.
    Language: ${targetLang}
    Return JSON Array: [{ id, title, description, difficulty }]
    Generate exactly 6 key topics.`;

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.ARRAY,
                items: {
                    type: Type.OBJECT,
                    properties: {
                        id: { type: Type.STRING },
                        title: { type: Type.STRING },
                        description: { type: Type.STRING },
                        difficulty: { type: Type.STRING }
                    }
                }
            }
        }
    });

    if (response.text) return JSON.parse(response.text) as MathTopic[];
    return [];
};

export const explainMathConcept = async (topic: string, language: LanguageCode = 'en'): Promise<MathConcept> => {
    const ai = getAIClient();
    const targetLang = LANGUAGE_PROMPT_NAMES[language] || 'English';

    const prompt = `Explain the math concept "${topic}" simply.
    Language: ${targetLang}.
    Return JSON: { explanation, exampleProblem, solution }`;

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    explanation: { type: Type.STRING },
                    exampleProblem: { type: Type.STRING },
                    solution: { type: Type.STRING }
                }
            }
        }
    });

    if (response.text) return JSON.parse(response.text) as MathConcept;
    throw new Error("Failed to explain concept");
};

// --- Skill Forge Service ---

export const generateSkillScenario = async (category: string, language: LanguageCode = 'en'): Promise<SkillChallenge> => {
    const ai = getAIClient();
    const targetLang = LANGUAGE_PROMPT_NAMES[language] || 'English';

    const prompt = `Generate a real-world training scenario for: ${category}.
    Language: ${targetLang}.
    Constraints: 
    - Difficult but solvable.
    - Requires critical thinking or soft skills.
    Return JSON: { id, title, scenario, difficulty (Easy/Medium/Hard), category }`;

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    id: { type: Type.STRING },
                    title: { type: Type.STRING },
                    scenario: { type: Type.STRING },
                    difficulty: { type: Type.STRING },
                    category: { type: Type.STRING }
                }
            }
        }
    });

    if (response.text) return JSON.parse(response.text) as SkillChallenge;
    throw new Error("Failed to generate scenario");
};

export const evaluateSkillResponse = async (scenario: string, userResponse: string, language: LanguageCode = 'en'): Promise<SkillEvaluation> => {
    const ai = getAIClient();
    const targetLang = LANGUAGE_PROMPT_NAMES[language] || 'English';

    const prompt = `Evaluate this user response to a training scenario.
    Scenario: "${scenario}"
    User Response: "${userResponse}"
    Language: ${targetLang}
    
    Task:
    1. Score it 0-100 based on effectiveness.
    2. Provide constructive feedback.
    3. List 2 strengths and 2 improvements.
    4. Write a "Better Example" response that a master would give.
    
    Return JSON.`;

    const response = await ai.models.generateContent({
        model: "gemini-3-pro-preview", // Use Pro for better evaluation
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    score: { type: Type.INTEGER },
                    feedback: { type: Type.STRING },
                    strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
                    improvements: { type: Type.ARRAY, items: { type: Type.STRING } },
                    betterExample: { type: Type.STRING }
                }
            }
        }
    });

    if (response.text) return JSON.parse(response.text) as SkillEvaluation;
    throw new Error("Failed to evaluate response");
};

// --- MindMeld Service (Live API) ---

function createBlob(data: Float32Array): { data: string; mimeType: string } {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  
  let binary = '';
  const bytes = new Uint8Array(int16.buffer);
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  const base64 = btoa(binary);

  return {
    data: base64,
    mimeType: 'audio/pcm;rate=16000',
  };
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

export class LiveSession {
  private sessionPromise: Promise<any> | null = null;
  public inputAudioContext: AudioContext | null = null;
  public outputAudioContext: AudioContext | null = null;
  public inputAnalyser: AnalyserNode | null = null;
  public outputAnalyser: AnalyserNode | null = null;
  
  private nextStartTime: number = 0;
  private sources = new Set<AudioBufferSourceNode>();
  private stream: MediaStream | null = null;

  async connect(config: { 
      systemInstruction: string, 
      voiceName: string, 
      onStatusChange: (status: string) => void 
  }) {
    const ai = getAIClient();
    this.inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
    this.outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    
    this.inputAnalyser = this.inputAudioContext.createAnalyser();
    this.inputAnalyser.fftSize = 256;
    this.outputAnalyser = this.outputAudioContext.createAnalyser();
    this.outputAnalyser.fftSize = 256;

    try {
        this.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (e) {
        console.error("Mic permission denied", e);
        config.onStatusChange("ERROR");
        return;
    }

    config.onStatusChange("CONNECTING");

    this.sessionPromise = ai.live.connect({
      model: 'gemini-2.5-flash-native-audio-preview-09-2025',
      callbacks: {
        onopen: () => {
          config.onStatusChange("CONNECTED");
          this.startAudioInput();
        },
        onmessage: async (message: LiveServerMessage) => {
          const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
          if (base64Audio && this.outputAudioContext) {
             this.playAudioOutput(base64Audio);
          }
          
          const interrupted = message.serverContent?.interrupted;
          if (interrupted) {
              this.stopAllAudio();
          }
        },
        onclose: () => {
            config.onStatusChange("DISCONNECTED");
        },
        onerror: (e) => {
          console.error("Live API Error", e);
          config.onStatusChange("ERROR");
        }
      },
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: config.voiceName } },
        },
        systemInstruction: config.systemInstruction,
      }
    });
  }

  private startAudioInput() {
    if (!this.inputAudioContext || !this.stream || !this.sessionPromise || !this.inputAnalyser) return;
    
    const source = this.inputAudioContext.createMediaStreamSource(this.stream);
    source.connect(this.inputAnalyser);

    const scriptProcessor = this.inputAudioContext.createScriptProcessor(4096, 1, 1);
    
    scriptProcessor.onaudioprocess = (e) => {
      const inputData = e.inputBuffer.getChannelData(0);
      const pcmBlob = createBlob(inputData);
      this.sessionPromise?.then(session => {
        session.sendRealtimeInput({ media: pcmBlob });
      });
    };

    source.connect(scriptProcessor);
    scriptProcessor.connect(this.inputAudioContext.destination);
  }

  private async playAudioOutput(base64Audio: string) {
    if (!this.outputAudioContext || !this.outputAnalyser) return;
    
    this.nextStartTime = Math.max(this.nextStartTime, this.outputAudioContext.currentTime);
    const audioBuffer = await decodeAudioData(
        decode(base64Audio),
        this.outputAudioContext,
        24000,
        1
    );
    
    const source = this.outputAudioContext.createBufferSource();
    source.buffer = audioBuffer;
    
    source.connect(this.outputAnalyser);
    this.outputAnalyser.connect(this.outputAudioContext.destination);
    
    source.addEventListener('ended', () => {
        this.sources.delete(source);
    });
    
    source.start(this.nextStartTime);
    this.nextStartTime += audioBuffer.duration;
    this.sources.add(source);
  }

  private stopAllAudio() {
      for (const source of this.sources) {
          source.stop();
      }
      this.sources.clear();
      this.nextStartTime = 0;
  }

  disconnect() {
      this.sessionPromise?.then(session => {
          try { session.close(); } catch(e) { console.log("Session already closed"); }
      });
      
      this.inputAudioContext?.close();
      this.outputAudioContext?.close();
      this.stream?.getTracks().forEach(t => t.stop());
  }
}
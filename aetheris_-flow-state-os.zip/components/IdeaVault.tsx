
import React, { useState, useEffect } from 'react';
import { AppProps, Note } from '../types';
import { TRANSLATIONS } from '../constants';
import { getNotes, saveNote, deleteNote } from '../services/storageService';
import { refineNote } from '../services/geminiService';
import { Plus, Save, Wand2, Trash2, Edit2, FileText, Loader2 } from 'lucide-react';

export const IdeaVault: React.FC<AppProps> = ({ language }) => {
    const t = TRANSLATIONS[language];
    const [notes, setNotes] = useState<Note[]>([]);
    const [selectedNote, setSelectedNote] = useState<Note | null>(null);
    const [isEditing, setIsEditing] = useState(false);
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        setNotes(getNotes());
    }, []);

    const handleNew = () => {
        setSelectedNote(null);
        setTitle('');
        setContent('');
        setIsEditing(true);
    };

    const handleSave = () => {
        if (!title.trim()) return alert("Title required");
        
        const newNote: Note = {
            id: selectedNote ? selectedNote.id : Date.now().toString(),
            title,
            content,
            tags: [],
            timestamp: Date.now()
        };

        saveNote(newNote);
        setNotes(getNotes()); // refresh
        setSelectedNote(newNote);
        setIsEditing(false);
    };

    const handleDelete = (id: string) => {
        if (confirm("Delete this entry?")) {
            deleteNote(id);
            setNotes(getNotes());
            if (selectedNote?.id === id) {
                setSelectedNote(null);
                setIsEditing(false);
            }
        }
    };

    const handleRefine = async () => {
        if (!content.trim()) return;
        setLoading(true);
        try {
            const refined = await refineNote(content, language);
            setContent(refined);
        } catch (e) {
            alert("Failed to refine note");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="h-full flex flex-col md:flex-row gap-6">
            {/* Sidebar List */}
            <div className="w-full md:w-72 flex-shrink-0 flex flex-col bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm h-[300px] md:h-full">
                <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                    <h3 className="font-bold text-slate-800">{t.vaultTitle}</h3>
                    <button 
                        onClick={handleNew} 
                        className="p-2 bg-slate-900 text-white rounded-lg hover:bg-slate-700 transition-colors"
                        title={t.newNote}
                    >
                        <Plus size={18} />
                    </button>
                </div>
                <div className="flex-1 overflow-y-auto p-2 space-y-2">
                    {notes.length === 0 && (
                        <div className="text-center text-slate-400 p-4 text-sm mt-4">
                            No entries yet.
                        </div>
                    )}
                    {notes.map(note => (
                        <div 
                            key={note.id}
                            onClick={() => { setSelectedNote(note); setTitle(note.title); setContent(note.content); setIsEditing(false); }}
                            className={`p-3 rounded-xl cursor-pointer border transition-all hover:bg-slate-50 ${selectedNote?.id === note.id ? 'bg-indigo-50 border-indigo-200 shadow-sm' : 'bg-white border-transparent'}`}
                        >
                            <div className="font-bold text-slate-800 truncate text-sm">{note.title}</div>
                            <div className="text-xs text-slate-500 truncate">{new Date(note.timestamp).toLocaleDateString()}</div>
                        </div>
                    ))}
                </div>
            </div>

            {/* Editor Area */}
            <div className="flex-1 bg-white border border-slate-200 rounded-2xl shadow-sm flex flex-col overflow-hidden">
                {isEditing || selectedNote ? (
                    <>
                        <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-white">
                            {isEditing ? (
                                <input 
                                    className="text-xl font-bold text-slate-900 outline-none w-full bg-transparent placeholder:text-slate-300"
                                    placeholder="Entry Title..."
                                    value={title}
                                    onChange={e => setTitle(e.target.value)}
                                />
                            ) : (
                                <h2 className="text-2xl font-bold text-slate-900">{selectedNote?.title}</h2>
                            )}
                            
                            <div className="flex gap-2">
                                {isEditing ? (
                                    <>
                                        <button 
                                            onClick={handleRefine}
                                            disabled={loading}
                                            className="px-3 py-2 text-indigo-600 bg-indigo-50 hover:bg-indigo-100 rounded-lg text-sm font-bold flex items-center gap-2 transition-colors"
                                        >
                                            {loading ? <Loader2 className="animate-spin" size={16} /> : <Wand2 size={16} />}
                                            {t.refineNote}
                                        </button>
                                        <button 
                                            onClick={handleSave}
                                            className="px-4 py-2 bg-indigo-600 text-white hover:bg-indigo-700 rounded-lg text-sm font-bold flex items-center gap-2 shadow-md"
                                        >
                                            <Save size={16} /> {t.saveNote}
                                        </button>
                                    </>
                                ) : (
                                    <>
                                        <button onClick={() => setIsEditing(true)} className="p-2 text-slate-500 hover:bg-slate-100 rounded-lg">
                                            <Edit2 size={18} />
                                        </button>
                                        <button onClick={() => selectedNote && handleDelete(selectedNote.id)} className="p-2 text-slate-500 hover:text-rose-500 hover:bg-rose-50 rounded-lg">
                                            <Trash2 size={18} />
                                        </button>
                                    </>
                                )}
                            </div>
                        </div>
                        <div className="flex-1 p-6 overflow-y-auto">
                            {isEditing ? (
                                <textarea 
                                    className="w-full h-full resize-none outline-none text-slate-700 leading-relaxed text-lg placeholder:text-slate-300"
                                    placeholder="Start writing..."
                                    value={content}
                                    onChange={e => setContent(e.target.value)}
                                />
                            ) : (
                                <div className="prose text-slate-700 whitespace-pre-wrap leading-relaxed text-lg">
                                    {selectedNote?.content}
                                </div>
                            )}
                        </div>
                    </>
                ) : (
                    <div className="h-full flex flex-col items-center justify-center text-slate-300">
                        <FileText size={64} className="mb-4 opacity-20" />
                        <p className="font-medium text-lg">Select an entry or create a new one.</p>
                        <button onClick={handleNew} className="mt-4 px-6 py-2 bg-indigo-50 text-indigo-600 rounded-xl font-bold hover:bg-indigo-100 transition-colors">
                            Create Entry
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};

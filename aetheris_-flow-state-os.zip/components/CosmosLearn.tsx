
import React, { useState } from 'react';
import { Search, Youtube, BookOpen, Clock, Loader2, Play, ExternalLink, PlayCircle } from 'lucide-react';
import { AppProps, LearningModule } from '../types';
import { generateLearningPlan } from '../services/geminiService';
import { TRANSLATIONS } from '../constants';

export const CosmosLearn: React.FC<AppProps> = ({ language }) => {
  const t = TRANSLATIONS[language];
  const [topic, setTopic] = useState('');
  const [plan, setPlan] = useState<LearningModule[]>([]);
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    if (!topic.trim()) return;
    setLoading(true);
    setPlan([]);
    try {
      const modules = await generateLearningPlan(topic, language);
      setPlan(modules);
    } catch (error) {
      console.error(error);
      alert("Failed to generate study plan.");
    } finally {
      setLoading(false);
    }
  };

  const openVideo = (url: string) => {
    window.open(url, '_blank');
  };

  return (
    <div className="h-full flex flex-col gap-6">
      <div className="flex-shrink-0">
          <h2 className="text-3xl font-bold text-slate-900 mb-2">{t.learnTitle}</h2>
          <p className="text-slate-500 text-lg">{t.learnDesc}</p>
      </div>

      {/* Search Box */}
      <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-sm">
          <div className="flex gap-2">
            <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400" size={20} />
                <input
                    type="text"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    placeholder="e.g. 'Intro to Python', 'Calculus', 'History of Rome'"
                    className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none transition-all"
                    onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                />
            </div>
            <button
                onClick={handleSearch}
                disabled={loading || !topic}
                className="bg-rose-600 hover:bg-rose-700 text-white px-8 rounded-xl font-bold transition-all shadow-md disabled:opacity-50 flex items-center gap-2"
            >
                {loading ? <Loader2 className="animate-spin" /> : <BookOpen />}
                <span className="hidden md:inline">{t.generatePlan}</span>
            </button>
          </div>
      </div>

      {/* Results Grid */}
      <div className="flex-1 overflow-y-auto pb-8">
          {loading ? (
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-pulse">
                 {[1,2,3,4,5].map(i => (
                     <div key={i} className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
                         <div className="h-48 bg-slate-200"></div>
                         <div className="p-4 space-y-3">
                             <div className="h-4 w-3/4 bg-slate-200 rounded"></div>
                             <div className="h-3 w-1/2 bg-slate-200 rounded"></div>
                         </div>
                     </div>
                 ))}
             </div>
          ) : plan.length > 0 ? (
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fade-in">
                 {plan.map((module, idx) => (
                     <div 
                        key={idx} 
                        onClick={() => openVideo(module.videoUrl)}
                        className="bg-white border border-slate-200 rounded-2xl shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all cursor-pointer group flex flex-col overflow-hidden"
                     >
                         {/* Thumbnail with Overlay */}
                         <div className="relative h-48 bg-slate-900 overflow-hidden">
                             <img 
                                src={module.thumbnail} 
                                alt={module.title}
                                onError={(e) => {
                                    (e.target as HTMLImageElement).src = `https://placehold.co/640x360/1e293b/FFF?text=${encodeURIComponent(module.title.substring(0,10))}`;
                                }}
                                className="w-full h-full object-cover opacity-80 group-hover:opacity-100 group-hover:scale-105 transition-all duration-500"
                             />
                             <div className="absolute inset-0 flex items-center justify-center">
                                 <div className="w-14 h-14 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center border border-white/40 group-hover:scale-110 transition-transform">
                                    <PlayCircle size={32} className="text-white fill-white/20" />
                                 </div>
                             </div>
                             <div className="absolute bottom-2 right-2 bg-black/70 text-white text-[10px] font-bold px-1.5 py-0.5 rounded">
                                 {module.duration}
                             </div>
                         </div>

                         {/* Content */}
                         <div className="p-5 flex flex-col flex-1">
                             <h3 className="text-lg font-bold text-slate-900 mb-1 leading-tight line-clamp-2 group-hover:text-rose-600 transition-colors">
                                 {module.title}
                             </h3>
                             <div className="flex items-center gap-2 mb-3">
                                 <Youtube size={14} className="text-rose-600" />
                                 <span className="text-xs font-semibold text-slate-500 truncate">{module.channelName}</span>
                             </div>
                             <p className="text-slate-500 text-sm mb-4 line-clamp-3 flex-1">{module.description}</p>
                             
                             <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                                 <span className="bg-slate-100 text-slate-600 text-[10px] font-bold px-2 py-1 rounded uppercase tracking-wider">
                                     {t.module} {idx + 1}
                                 </span>
                                 <span className="text-rose-600 text-xs font-bold flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                                     {t.watchVideo} <ExternalLink size={10} />
                                 </span>
                             </div>
                         </div>
                     </div>
                 ))}
             </div>
          ) : (
              <div className="h-64 flex flex-col items-center justify-center text-slate-300">
                  <Youtube size={64} className="mb-4 opacity-20" />
                  <p className="font-medium">Enter a topic to generate a video curriculum.</p>
              </div>
          )}
      </div>
    </div>
  );
};

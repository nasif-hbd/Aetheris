
import React, { useEffect, useState } from 'react';
import { AreaChart, Area, XAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { UserStats, View, AppProps } from '../types';
import { Activity, Network, Zap, Trophy, MessageSquare, BookOpen, Crown, Lightbulb, Cpu, HardDrive } from 'lucide-react';
import { TRANSLATIONS } from '../constants';
import { AetherisLogo } from './Logo';

interface DashboardProps extends AppProps {
  onNavigate: (view: View) => void;
}

const CountUp = ({ end, duration = 2000, suffix = '' }: { end: number, duration?: number, suffix?: string }) => {
  const [count, setCount] = useState(0);
  useEffect(() => {
    let startTime: number | null = null;
    let animationFrameId: number;
    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const progress = Math.min((currentTime - startTime) / duration, 1);
      const ease = 1 - Math.pow(1 - progress, 4); // Ease out quart
      setCount(Math.floor(ease * end));
      if (progress < 1) animationFrameId = requestAnimationFrame(animate);
    };
    animationFrameId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrameId);
  }, [end, duration]);
  return <>{count.toLocaleString()}{suffix}</>;
};

const AnimatedBar = ({ percentage, colorClass, delay = 0 }: { percentage: number, colorClass: string, delay?: number }) => {
    const [width, setWidth] = useState(0);
    useEffect(() => {
        const timer = setTimeout(() => setWidth(Math.min(100, Math.max(0, percentage))), 100 + delay);
        return () => clearTimeout(timer);
    }, [percentage, delay]);

    return (
        <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden mt-3">
            <div 
                className={`h-full ${colorClass} transition-all duration-1000 ease-out`}
                style={{ width: `${width}%` }}
            />
        </div>
    );
};

const StatCard: React.FC<{ 
  title: string; 
  value: React.ReactNode; 
  icon: any; 
  color: string; 
  subtext?: string;
  progress?: number;
  progressColor?: string;
}> = ({ title, value, icon: Icon, color, subtext, progress, progressColor }) => (
  <div className="bg-white rounded-2xl p-6 border border-slate-100 shadow-[0_4px_20px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_30px_rgba(0,0,0,0.06)] transition-all duration-300 hover:-translate-y-1 group relative overflow-hidden">
    <div className={`absolute top-0 right-0 w-24 h-24 bg-gradient-to-br ${color} opacity-10 rounded-bl-full -mr-4 -mt-4 transition-transform duration-500 group-hover:scale-110`}></div>
    <div className="flex items-start justify-between mb-2 relative z-10">
      <div>
         <p className="text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">{title}</p>
         <h3 className="text-3xl font-bold text-slate-800 tracking-tight">{value}</h3>
      </div>
      <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center text-white shadow-md group-hover:scale-110 group-hover:rotate-3 transition-all duration-300`}>
        <Icon size={24} />
      </div>
    </div>
    <div className="relative z-10">
        {subtext && <p className="text-xs text-slate-500 font-medium mb-1">{subtext}</p>}
        {progress !== undefined && progressColor && (
            <AnimatedBar percentage={progress} colorClass={progressColor} />
        )}
    </div>
  </div>
);

const NEURAL_SPARKS = [
  "Neuroplasticity allows your brain to rewire itself throughout your entire life.",
  "The human brain can process images that the eye sees for as little as 13 milliseconds.",
  "Information travels between neurons at speeds of up to 268 miles per hour.",
  "Your brain generates about 23 watts of power when awake—enough to power a lightbulb.",
  "Learning a new language increases the size of your brain's hippocampus."
];

export const Dashboard: React.FC<DashboardProps> = ({ stats, onNavigate, language }) => {
  const t = TRANSLATIONS[language];
  const [spark, setSpark] = useState("");

  useEffect(() => {
    const index = new Date().getDate() % NEURAL_SPARKS.length;
    setSpark(NEURAL_SPARKS[index]);
  }, []);

  // Calculate progress for bars
  const xpProgress = (stats.quizScore % 1000) / 10; // Simple level progress
  const nodesProgress = Math.min(100, (stats.nodesExplored / 50) * 100); // Goal: 50 nodes

  return (
    <div className="animate-slide-up space-y-8 pb-10">
      {/* HERO SECTION */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white p-8 md:p-10 shadow-xl group">
          <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
              <div>
                  <div className="flex items-center gap-2 mb-3 opacity-80">
                    <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></span>
                    <span className="text-xs font-bold uppercase tracking-widest text-emerald-400">System Online</span>
                  </div>
                  <h1 className="text-3xl md:text-5xl font-bold mb-3 tracking-tight font-sans">{t.welcome}</h1>
                  <p className="text-slate-300 text-lg opacity-90 max-w-lg font-light leading-relaxed">{t.welcomeSub}</p>
              </div>
              <div className="flex items-center gap-4 bg-white/5 backdrop-blur-xl px-6 py-4 rounded-2xl border border-white/10 shadow-2xl hover:bg-white/10 transition-all cursor-default group/rank">
                  <div className="bg-gradient-to-br from-amber-400 to-orange-500 p-2.5 rounded-xl shadow-lg group-hover/rank:scale-110 transition-transform">
                    <Trophy className="text-white" size={24} />
                  </div>
                  <div>
                      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Current Rank</div>
                      <div className="font-bold text-xl leading-none text-white">{stats.title}</div>
                  </div>
              </div>
          </div>
          
          {/* Decorative Backgrounds */}
          <div className="absolute top-1/2 right-0 -translate-y-1/2 translate-x-10 opacity-10 pointer-events-none transition-transform duration-1000 group-hover:scale-105 group-hover:rotate-6">
            <AetherisLogo className="w-80 h-80" />
          </div>
          <div className="absolute bottom-0 left-0 -mb-20 -ml-20 w-64 h-64 bg-indigo-600 opacity-20 rounded-full blur-[80px] animate-blob"></div>
          <div className="absolute top-0 right-0 -mt-20 -mr-20 w-64 h-64 bg-cyan-600 opacity-10 rounded-full blur-[80px] animate-blob animation-delay-2000"></div>
      </div>

      {/* STATS GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard 
            title={t.quizXp} 
            value={<CountUp end={stats.quizScore + (stats.nodesExplored * 10)} />} 
            icon={Zap} 
            color="from-amber-400 to-orange-500"
            subtext="Top 5% Global"
            progress={xpProgress}
            progressColor="bg-amber-500"
          />
          <StatCard 
            title={t.concepts} 
            value={<CountUp end={stats.nodesExplored} />} 
            icon={Network} 
            color="from-blue-400 to-cyan-500"
            subtext="Knowledge Nodes"
            progress={nodesProgress}
            progressColor="bg-cyan-500"
          />
          <StatCard 
            title={t.debateTime} 
            value={<CountUp end={stats.minutesDebated} suffix="m" />} 
            icon={Activity} 
            color="from-emerald-400 to-teal-500"
            subtext="Voice Interaction"
          />
          <StatCard 
            title="System Level" 
            value={stats.level} 
            icon={Crown} 
            color="from-rose-400 to-pink-500"
            subtext={`Next level in ${100 - Math.floor(xpProgress)}%`}
            progress={xpProgress}
            progressColor="bg-rose-500"
          />
      </div>

      {/* MAIN ACTIONS & CHARTS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Activity Chart */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm flex flex-col">
              <div className="flex items-center justify-between mb-6">
                  <h3 className="font-bold text-lg text-slate-800 flex items-center gap-2">
                      <div className="p-2 bg-indigo-50 rounded-lg text-indigo-600">
                        <Activity size={20}/> 
                      </div>
                      Weekly Cognitive Load
                  </h3>
                  <div className="flex gap-2">
                      <span className="w-3 h-3 rounded-full bg-indigo-500 animate-pulse"></span>
                      <span className="text-xs text-slate-500 font-medium">Focus Intensity</span>
                  </div>
              </div>
              <div className="flex-1 min-h-[250px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={stats.weeklyActivity}>
                      <defs>
                          <linearGradient id="colorVal" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#6366f1" stopOpacity={0.4}/>
                          <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                          </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis 
                        dataKey="day" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{fill: '#94a3b8', fontSize: 12, fontWeight: 500}} 
                        dy={10} 
                      />
                      <Tooltip 
                          contentStyle={{ 
                            borderRadius: '12px', 
                            border: 'none', 
                            boxShadow: '0 10px 30px rgba(0,0,0,0.1)',
                            padding: '12px 16px',
                            fontWeight: 'bold'
                          }}
                          cursor={{ stroke: '#6366f1', strokeWidth: 2, strokeDasharray: '4 4' }}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="value" 
                        stroke="#6366f1" 
                        strokeWidth={4} 
                        fillOpacity={1} 
                        fill="url(#colorVal)" 
                        animationDuration={2000}
                      />
                      </AreaChart>
                  </ResponsiveContainer>
              </div>
            </div>

            {/* System Status Bars */}
            <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm">
                <h3 className="font-bold text-lg text-slate-800 mb-4">{t.systemStatus}</h3>
                <div className="space-y-4">
                    <div>
                        <div className="flex justify-between text-xs font-bold text-slate-500 mb-1">
                            <span className="flex items-center gap-1"><Cpu size={12}/> Neural Load</span>
                            <span>34%</span>
                        </div>
                        <AnimatedBar percentage={34} colorClass="bg-indigo-500" />
                    </div>
                    <div>
                        <div className="flex justify-between text-xs font-bold text-slate-500 mb-1">
                            <span className="flex items-center gap-1"><HardDrive size={12}/> Memory Banks</span>
                            <span>{Math.min(100, stats.nodesExplored)}%</span>
                        </div>
                        <AnimatedBar percentage={Math.min(100, stats.nodesExplored)} colorClass="bg-emerald-500" delay={200} />
                    </div>
                </div>
            </div>
          </div>

          {/* Quick Actions & Daily Spark */}
          <div className="space-y-6">
              
              {/* Daily Neural Spark Card */}
              <div className="bg-gradient-to-br from-indigo-900 to-slate-900 rounded-3xl p-6 text-white relative overflow-hidden shadow-lg border border-white/10 group cursor-default transition-all hover:shadow-xl">
                <div className="flex items-center gap-2 mb-3 text-amber-400">
                  <Lightbulb size={18} fill="currentColor" className="group-hover:animate-pulse" />
                  <span className="text-xs font-bold uppercase tracking-widest">Daily Neural Spark</span>
                </div>
                <p className="text-lg font-medium leading-relaxed opacity-90 relative z-10 transition-transform group-hover:translate-x-1">
                  "{spark}"
                </p>
                <div className="absolute -bottom-4 -right-4 opacity-10 rotate-12 transition-transform duration-700 group-hover:rotate-45 group-hover:scale-110">
                   <AetherisLogo className="w-32 h-32" />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-3">
                <div 
                  onClick={() => onNavigate(View.NEXUS_CHAT)}
                  className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md hover:border-indigo-100 transition-all cursor-pointer flex items-center gap-4 group"
                >
                    <div className="w-10 h-10 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-colors duration-300">
                        <MessageSquare size={18} />
                    </div>
                    <div className="flex-1">
                        <h4 className="font-bold text-slate-900 text-sm group-hover:text-indigo-600 transition-colors">{t.nexusChat}</h4>
                        <p className="text-xs text-slate-500">Ask the AI anything</p>
                    </div>
                </div>

                <div 
                  onClick={() => onNavigate(View.COSMOS_LEARN)}
                  className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md hover:border-rose-100 transition-all cursor-pointer flex items-center gap-4 group"
                >
                    <div className="w-10 h-10 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center group-hover:bg-rose-600 group-hover:text-white transition-colors duration-300">
                        <BookOpen size={18} />
                    </div>
                    <div className="flex-1">
                        <h4 className="font-bold text-slate-900 text-sm group-hover:text-rose-600 transition-colors">{t.cosmosLearn}</h4>
                        <p className="text-xs text-slate-500">Find free courses</p>
                    </div>
                </div>
                
                <div 
                  onClick={() => onNavigate(View.MINDMELD)}
                  className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md hover:border-emerald-100 transition-all cursor-pointer flex items-center gap-4 group"
                >
                    <div className="w-10 h-10 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-colors duration-300">
                        <Activity size={18} />
                    </div>
                    <div className="flex-1">
                        <h4 className="font-bold text-slate-900 text-sm group-hover:text-emerald-600 transition-colors">{t.mindMeld}</h4>
                        <p className="text-xs text-slate-500">Live Voice Debate</p>
                    </div>
                </div>
              </div>
          </div>

      </div>
    </div>
  );
};

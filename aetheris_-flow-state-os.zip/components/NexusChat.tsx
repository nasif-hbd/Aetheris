
import React, { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, Trash2, Bot, Network, Zap, ChevronDown, Check, Globe, Brain, ExternalLink, Cpu } from 'lucide-react';
import { ChatMessage, AppProps } from '../types';
import { sendChatMessage } from '../services/geminiService';
import { getChatHistory, saveChatHistory, clearChatHistory } from '../services/storageService';
import { TRANSLATIONS, AI_MODELS } from '../constants';

const SUGGESTIONS = [
  "Explain Quantum Physics",
  "Summarize the French Revolution",
  "Write a Python script for...",
  "Best way to learn Spanish?"
];

const PROCESSING_STEPS = [
  "Activating Neural Layer 1...",
  "Routing to Deep Learning Core...",
  "Analyzing Pattern Recognition...",
  "Consulting Multi-Network Nodes...",
  "Synthesizing Logic Gates...",
  "Finalizing Output..."
];

export const NexusChat: React.FC<AppProps> = ({ language }) => {
  const t = TRANSLATIONS[language];
  const [messages, setMessages] = useState<ChatMessage[]>(() => getChatHistory());
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [webSearch, setWebSearch] = useState(false);
  const [deepThink, setDeepThink] = useState(false);
  const [processStep, setProcessStep] = useState(0);
  
  // Model Selection
  const [selectedModelId, setSelectedModelId] = useState(AI_MODELS[0].id);
  const [isModelMenuOpen, setIsModelMenuOpen] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const activeModel = AI_MODELS.find(m => m.id === selectedModelId) || AI_MODELS[0];

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    scrollToBottom();
    saveChatHistory(messages);
  }, [messages, loading]);

  // Cycle through "Neural Network" processing steps during Deep Think
  useEffect(() => {
      let interval: any;
      if (loading && deepThink) {
          setProcessStep(0);
          interval = setInterval(() => {
              setProcessStep(prev => (prev + 1) % PROCESSING_STEPS.length);
          }, 800);
      }
      return () => clearInterval(interval);
  }, [loading, deepThink]);

  const scrollToBottom = () => {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleClearChat = () => {
    if (confirm("Clear history?")) {
      setMessages([]);
      clearChatHistory();
    }
  };

  const handleSend = async (textOverride?: string) => {
    const textToSend = textOverride || input;
    if (!textToSend.trim() || loading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: textToSend,
      timestamp: Date.now()
    };

    // 1. Immediate UI Update
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);
    
    // Force immediate scroll
    setTimeout(scrollToBottom, 10);

    try {
      const response = await sendChatMessage(
          [...messages, userMsg], 
          textToSend, 
          language, 
          { 
              webSearch, 
              deepThink,
              modelId: selectedModelId 
          }
      );
      const aiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: response.text,
        timestamp: Date.now(),
        sources: response.sources,
        isThinking: deepThink,
        modelUsed: activeModel.name
      };
      setMessages(prev => [...prev, aiMsg]);
    } catch (error) {
       const err: ChatMessage = {
           id: Date.now().toString(),
           role: 'model',
           text: "Error connecting to Neural Core. Please try again.",
           timestamp: Date.now()
       };
       setMessages(prev => [...prev, err]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-[calc(100vh-140px)] md:h-full flex flex-col bg-white border border-slate-200 rounded-3xl shadow-sm overflow-hidden animate-slide-up">
      {/* Chat Header */}
      <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-white/80 backdrop-blur-md z-10 relative">
        <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-tr from-indigo-600 to-violet-600 rounded-full flex items-center justify-center text-white shadow-lg shadow-indigo-200 relative group overflow-hidden">
                <Network size={20} className="relative z-10" />
                <div className="absolute inset-0 bg-white/20 blur-md group-hover:translate-y-full transition-transform duration-700"></div>
            </div>
            <div>
                <h2 className="font-bold text-slate-900 leading-tight">Nexus AI</h2>
                <button 
                  onClick={() => setIsModelMenuOpen(!isModelMenuOpen)}
                  className="flex items-center gap-1.5 text-[10px] font-bold text-slate-500 uppercase tracking-wide hover:text-indigo-600 transition-colors"
                >
                    <span className={`w-2 h-2 rounded-full ${activeModel.isPro ? 'bg-indigo-500' : 'bg-emerald-500'} animate-pulse`}></span>
                    {activeModel.name}
                    <ChevronDown size={10} />
                </button>
            </div>
        </div>
        
        {/* Model Selector Dropdown */}
        {isModelMenuOpen && (
            <div className="absolute top-16 left-4 bg-white border border-slate-200 rounded-xl shadow-xl p-2 z-50 w-64 animate-fade-in">
                <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 px-2">Select Neural Engine</div>
                {AI_MODELS.map(model => (
                    <button
                        key={model.id}
                        onClick={() => { setSelectedModelId(model.id); setIsModelMenuOpen(false); }}
                        className={`w-full text-left p-3 rounded-lg flex items-center gap-3 transition-colors ${selectedModelId === model.id ? 'bg-indigo-50 border border-indigo-100' : 'hover:bg-slate-50'}`}
                    >
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${model.isPro ? 'bg-indigo-100 text-indigo-600' : 'bg-emerald-100 text-emerald-600'}`}>
                            {model.icon === 'Zap' ? <Zap size={16}/> : model.icon === 'Brain' ? <Brain size={16}/> : <Sparkles size={16}/>}
                        </div>
                        <div className="flex-1">
                            <div className="text-sm font-bold text-slate-900 flex items-center gap-2">
                                {model.name}
                                {selectedModelId === model.id && <Check size={14} className="text-indigo-600"/>}
                            </div>
                            <div className="text-[10px] text-slate-500">{model.description}</div>
                        </div>
                    </button>
                ))}
            </div>
        )}

        <button onClick={handleClearChat} className="p-2 hover:bg-slate-100 rounded-full text-slate-400 hover:text-rose-500 transition-colors">
            <Trash2 size={18} />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6 bg-slate-50/50" ref={scrollRef}>
        {messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-slate-400 opacity-60">
                <div className="w-24 h-24 bg-indigo-50 rounded-full flex items-center justify-center mb-6 animate-pulse">
                    <Cpu size={40} className="text-indigo-400" />
                </div>
                <h3 className="font-bold text-lg text-slate-600 mb-2">Aetheris Deep Learning</h3>
                <p className="font-medium text-sm text-center max-w-xs">Ready to route queries through multi-expert nodes using <span className="text-indigo-500 font-bold">{activeModel.name}</span>.</p>
                <div className="grid grid-cols-2 gap-2 mt-8">
                    {SUGGESTIONS.map((s, i) => (
                        <button key={i} onClick={() => handleSend(s)} className="text-xs bg-white border border-slate-200 px-3 py-2 rounded-lg hover:border-indigo-400 transition-colors text-slate-600">{s}</button>
                    ))}
                </div>
            </div>
        )}
        
        {messages.map((msg) => (
          <div key={msg.id} className={`flex w-full ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-slide-up group`}>
            {msg.role === 'model' && (
               <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center mr-2 flex-shrink-0 mt-2">
                  <Bot size={14} className="text-indigo-600" />
               </div>
            )}
            <div className={`max-w-[85%] md:max-w-[75%] p-4 text-sm leading-relaxed shadow-sm transition-all hover:shadow-md ${
                msg.role === 'user' 
                ? 'bg-indigo-600 text-white rounded-2xl rounded-tr-sm' 
                : 'bg-white text-slate-700 border border-slate-100 rounded-2xl rounded-tl-sm'
            }`}>
              <div className="whitespace-pre-wrap">{msg.text}</div>
              
              {msg.sources && msg.sources.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-dashed border-slate-200">
                      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 flex items-center gap-1">
                          <Globe size={10} /> Sources
                      </div>
                      <div className="flex flex-wrap gap-2">
                          {msg.sources.map((source, idx) => (
                              <a 
                                key={idx} 
                                href={source.uri} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="text-[10px] bg-slate-50 hover:bg-indigo-50 text-indigo-600 px-2 py-1 rounded border border-slate-200 hover:border-indigo-200 transition-colors flex items-center gap-1 truncate max-w-[150px]"
                              >
                                  {source.title} <ExternalLink size={8} />
                              </a>
                          ))}
                      </div>
                  </div>
              )}

              {msg.role === 'model' && (
                  <div className="mt-2 flex items-center gap-2 opacity-50 text-[10px]">
                      {msg.modelUsed && <span className="font-bold">{msg.modelUsed}</span>}
                      {msg.isThinking && <span className="px-1.5 py-0.5 bg-indigo-50 text-indigo-600 rounded">Deep Reasoning</span>}
                  </div>
              )}
            </div>
          </div>
        ))}
        
        {loading && (
            <div className="flex w-full justify-start animate-fade-in">
               <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center mr-2 flex-shrink-0">
                  <Bot size={14} className="text-indigo-600 animate-pulse" />
               </div>
               <div className="bg-white border border-slate-100 p-4 rounded-2xl rounded-tl-sm shadow-sm flex flex-col gap-2 min-w-[200px]">
                   <div className="flex items-center gap-2">
                       <span className="flex space-x-1">
                           <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                           <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                           <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce"></span>
                       </span>
                   </div>
                   {deepThink && (
                       <div className="text-xs text-indigo-500 font-mono mt-1 flex items-center gap-2 animate-pulse">
                           <Brain size={12} />
                           {PROCESSING_STEPS[processStep]}
                       </div>
                   )}
               </div>
            </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 bg-white border-t border-slate-100">
        
        {/* Feature Toggles */}
        <div className="flex gap-2 mb-3">
            <button 
                onClick={() => setWebSearch(!webSearch)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all border ${
                    webSearch 
                    ? 'bg-sky-50 text-sky-600 border-sky-200' 
                    : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'
                }`}
            >
                <Globe size={14} />
                {t.webSearch}
            </button>
            <button 
                onClick={() => setDeepThink(!deepThink)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all border ${
                    deepThink 
                    ? 'bg-violet-50 text-violet-600 border-violet-200' 
                    : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'
                }`}
            >
                <Brain size={14} />
                {t.deepThink}
            </button>
        </div>

        <div className="flex gap-2 relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder={t.chatPlaceholder}
            className="flex-1 bg-slate-50 text-slate-900 placeholder-slate-400 border border-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
            disabled={loading}
          />
          <button
            onClick={() => handleSend()}
            disabled={!input.trim() || loading}
            className="bg-indigo-600 text-white p-3 rounded-xl hover:bg-indigo-700 disabled:opacity-50 disabled:hover:bg-indigo-600 transition-all shadow-md flex-shrink-0"
          >
            <Send size={20} />
          </button>
        </div>
        <div className="text-center mt-2">
            <p className="text-[10px] text-slate-400 font-medium">Aetheris AI can make mistakes. Check important info.</p>
        </div>
      </div>
    </div>
  );
};

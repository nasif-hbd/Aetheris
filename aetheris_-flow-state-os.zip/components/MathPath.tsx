
import React, { useState } from 'react';
import { AppProps, MathTopic, MathConcept } from '../types';
import { generateMathRoadmap, explainMathConcept } from '../services/geminiService';
import { TRANSLATIONS } from '../constants';
import { Calculator, ChevronRight, BookOpen, Loader2, ArrowRight, CheckCircle2 } from 'lucide-react';

export const MathPath: React.FC<AppProps> = ({ language }) => {
    const t = TRANSLATIONS[language];
    const [level, setLevel] = useState<'Beginner' | 'Intermediate' | 'Advanced' | null>(null);
    const [topics, setTopics] = useState<MathTopic[]>([]);
    const [selectedTopic, setSelectedTopic] = useState<MathTopic | null>(null);
    const [conceptData, setConceptData] = useState<MathConcept | null>(null);
    const [loading, setLoading] = useState(false);
    const [explaining, setExplaining] = useState(false);

    const handleLevelSelect = async (lvl: 'Beginner' | 'Intermediate' | 'Advanced') => {
        setLevel(lvl);
        setLoading(true);
        setTopics([]);
        setSelectedTopic(null);
        setConceptData(null);
        try {
            const roadmap = await generateMathRoadmap(lvl, language);
            setTopics(roadmap);
        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };

    const handleTopicClick = async (topic: MathTopic) => {
        setSelectedTopic(topic);
        setExplaining(true);
        setConceptData(null);
        try {
            const explanation = await explainMathConcept(topic.title, language);
            setConceptData(explanation);
        } catch (e) {
            console.error(e);
        } finally {
            setExplaining(false);
        }
    };

    return (
        <div className="h-full flex flex-col gap-6 animate-slide-up">
            <div>
                <h2 className="text-3xl font-bold text-slate-900 mb-2">{t.mathTitle}</h2>
                <p className="text-slate-500 text-lg">{t.mathDesc}</p>
            </div>

            {/* Level Selector */}
            <div className="grid grid-cols-3 gap-4">
                {['Beginner', 'Intermediate', 'Advanced'].map((lvl) => (
                    <button
                        key={lvl}
                        onClick={() => handleLevelSelect(lvl as any)}
                        className={`p-4 rounded-xl border-2 transition-all font-bold flex flex-col items-center gap-2 ${
                            level === lvl 
                            ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg' 
                            : 'bg-white border-slate-200 text-slate-600 hover:border-indigo-300 hover:bg-slate-50'
                        }`}
                    >
                        <Calculator size={24} className={level === lvl ? 'text-indigo-200' : 'text-slate-400'}/>
                        {t[lvl.toLowerCase() as keyof typeof t]}
                    </button>
                ))}
            </div>

            {/* Content Area */}
            <div className="flex-1 flex flex-col md:flex-row gap-6 overflow-hidden">
                {/* Roadmap List */}
                <div className="flex-1 bg-white border border-slate-200 rounded-2xl shadow-sm overflow-y-auto">
                    {loading ? (
                        <div className="h-full flex items-center justify-center text-indigo-600">
                            <Loader2 className="animate-spin" size={32} />
                        </div>
                    ) : topics.length > 0 ? (
                        <div className="p-2 space-y-2">
                            {topics.map((topic, idx) => (
                                <button
                                    key={idx}
                                    onClick={() => handleTopicClick(topic)}
                                    className={`w-full p-4 rounded-xl text-left border transition-all flex items-center justify-between group ${
                                        selectedTopic?.id === topic.id 
                                        ? 'bg-indigo-50 border-indigo-200 shadow-sm' 
                                        : 'bg-white border-transparent hover:bg-slate-50'
                                    }`}
                                >
                                    <div>
                                        <div className="font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                                            {topic.title}
                                        </div>
                                        <div className="text-xs text-slate-500">{topic.description}</div>
                                    </div>
                                    <ChevronRight size={16} className={`text-slate-300 group-hover:text-indigo-500 ${selectedTopic?.id === topic.id ? 'text-indigo-500' : ''}`} />
                                </button>
                            ))}
                        </div>
                    ) : (
                        <div className="h-full flex flex-col items-center justify-center text-slate-300 p-6 text-center">
                            <ArrowRight size={48} className="mb-4 opacity-20" />
                            <p>Select a difficulty level to generate your learning path.</p>
                        </div>
                    )}
                </div>

                {/* Explanation Detail */}
                <div className="flex-[1.5] bg-white border border-slate-200 rounded-2xl shadow-sm overflow-y-auto p-6 relative">
                    {selectedTopic ? (
                        explaining ? (
                            <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/80 backdrop-blur-sm z-10">
                                <Loader2 className="animate-spin text-indigo-600 mb-2" size={32} />
                                <span className="text-sm font-bold text-slate-500 animate-pulse">Analyzing Concept...</span>
                            </div>
                        ) : conceptData ? (
                            <div className="space-y-6 animate-fade-in">
                                <div>
                                    <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">{t.mathConcept}</div>
                                    <h3 className="text-2xl font-bold text-slate-900 mb-4">{selectedTopic.title}</h3>
                                    <p className="text-slate-700 leading-relaxed text-lg">{conceptData.explanation}</p>
                                </div>
                                
                                <div className="bg-slate-50 rounded-xl p-6 border border-slate-100">
                                    <div className="flex items-center gap-2 font-bold text-slate-900 mb-3">
                                        <BookOpen size={18} className="text-indigo-600" /> Example Problem
                                    </div>
                                    <div className="font-mono text-sm bg-white p-4 rounded-lg border border-slate-200 mb-4 shadow-inner">
                                        {conceptData.exampleProblem}
                                    </div>
                                    
                                    <div className="flex items-center gap-2 font-bold text-slate-900 mb-2">
                                        <CheckCircle2 size={18} className="text-emerald-600" /> Solution
                                    </div>
                                    <div className="text-slate-700">
                                        {conceptData.solution}
                                    </div>
                                </div>
                            </div>
                        ) : null
                    ) : (
                         <div className="h-full flex flex-col items-center justify-center text-slate-300 p-6 text-center">
                            <Calculator size={64} className="mb-4 opacity-20" />
                            <p>Select a topic from the roadmap to view the lesson.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

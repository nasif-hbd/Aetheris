
import React from 'react';

export const AetherisLogo: React.FC<{ className?: string }> = ({ className = "w-10 h-10" }) => {
  return (
    <svg viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
      <defs>
        <linearGradient id="silverGradient" x1="0" y1="0" x2="200" y2="200" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#E2E8F0" />
          <stop offset="0.5" stopColor="#94A3B8" />
          <stop offset="1" stopColor="#475569" />
        </linearGradient>
        <linearGradient id="flowGradient" x1="0" y1="100" x2="200" y2="100" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#3B82F6" stopOpacity="0.8" />
          <stop offset="1" stopColor="#06B6D4" stopOpacity="0.8" />
        </linearGradient>
        <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="5" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
      </defs>
      
      {/* The "A" Shape - Metallic Finish */}
      <path 
        d="M60 160 L100 40 L140 160 M75 115 H125" 
        stroke="url(#silverGradient)" 
        strokeWidth="24" 
        strokeLinecap="round" 
        strokeLinejoin="round" 
      />
      
      {/* Flowing Lines (The "Ether") */}
      <path 
        d="M40 140 C 70 120, 100 180, 160 80" 
        stroke="url(#flowGradient)" 
        strokeWidth="6" 
        strokeLinecap="round"
        className="opacity-90"
      />
      <path 
        d="M30 150 C 60 130, 90 190, 170 70" 
        stroke="url(#flowGradient)" 
        strokeWidth="4" 
        strokeLinecap="round"
        className="opacity-70"
      />
      <path 
        d="M50 130 C 80 110, 110 170, 150 90" 
        stroke="url(#flowGradient)" 
        strokeWidth="3" 
        strokeLinecap="round"
        className="opacity-50"
      />

      {/* The Blue Orbital Dot */}
      <circle cx="160" cy="80" r="8" fill="#3B82F6" filter="url(#glow)" />
      
      {/* Tech Nodes (Subtle) */}
      <circle cx="40" cy="140" r="3" fill="#94A3B8" />
      <circle cx="100" cy="40" r="3" fill="#94A3B8" />
    </svg>
  );
};

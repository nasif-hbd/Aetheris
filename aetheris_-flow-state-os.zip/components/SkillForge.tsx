
import React, { useState } from 'react';
import { AppProps, SkillChallenge, SkillEvaluation } from '../types';
import { generateSkillScenario, evaluateSkillResponse } from '../services/geminiService';
import { TRANSLATIONS, SKILL_CATEGORIES } from '../constants';
import { MessageCircle, BrainCircuit, Puzzle, Flag, Heart, Loader2, ArrowRight, CheckCircle, AlertTriangle } from 'lucide-react';

const icons: Record<string, any> = {
    MessageCircle, BrainCircuit, Puzzle, Flag, Heart
};

export const SkillForge: React.FC<AppProps> = ({ language }) => {
    const t = TRANSLATIONS[language];
    const [view, setView] = useState<'SELECT' | 'SCENARIO' | 'RESULT'>('SELECT');
    const [selectedCategory, setSelectedCategory] = useState('');
    const [scenario, setScenario] = useState<SkillChallenge | null>(null);
    const [userResponse, setUserResponse] = useState('');
    const [evaluation, setEvaluation] = useState<SkillEvaluation | null>(null);
    const [loading, setLoading] = useState(false);

    const handleStart = async (categoryId: string) => {
        setSelectedCategory(categoryId);
        setLoading(true);
        setView('SCENARIO');
        setScenario(null);
        setUserResponse('');
        setEvaluation(null);
        try {
            const data = await generateSkillScenario(categoryId, language);
            setScenario(data);
        } catch (e) {
            alert("Failed to generate scenario");
            setView('SELECT');
        } finally {
            setLoading(false);
        }
    };

    const handleEvaluate = async () => {
        if (!scenario || !userResponse.trim()) return;
        setLoading(true);
        try {
            const result = await evaluateSkillResponse(scenario.scenario, userResponse, language);
            setEvaluation(result);
            setView('RESULT');
        } catch (e) {
            alert("Evaluation failed");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="h-full flex flex-col gap-6 animate-slide-up">
            <div>
                <h2 className="text-3xl font-bold text-slate-900 mb-2">{t.skillTitle}</h2>
                <p className="text-slate-500 text-lg">{t.skillDesc}</p>
            </div>

            {view === 'SELECT' && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {SKILL_CATEGORIES.map(cat => {
                        const Icon = icons[cat.icon];
                        return (
                            <button
                                key={cat.id}
                                onClick={() => handleStart(cat.id)}
                                disabled={loading}
                                className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-lg hover:border-indigo-300 transition-all text-left flex flex-col gap-4 group"
                            >
                                <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                                    <Icon size={24} />
                                </div>
                                <div>
                                    <h3 className="font-bold text-lg text-slate-900">{cat.label}</h3>
                                    <p className="text-slate-500 text-sm mt-1">{cat.desc}</p>
                                </div>
                            </button>
                        );
                    })}
                </div>
            )}

            {view === 'SCENARIO' && (
                <div className="flex-1 bg-white border border-slate-200 rounded-2xl shadow-sm p-6 md:p-8 flex flex-col relative overflow-hidden">
                    {loading ? (
                        <div className="h-full flex flex-col items-center justify-center text-indigo-600">
                            <Loader2 size={48} className="animate-spin mb-4" />
                            <p className="font-bold animate-pulse">Designing Simulation...</p>
                        </div>
                    ) : scenario ? (
                        <>
                            <div className="flex items-center justify-between mb-6">
                                <span className="bg-amber-100 text-amber-700 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">{scenario.difficulty} Scenario</span>
                                <span className="text-slate-400 font-bold text-sm uppercase">{scenario.category}</span>
                            </div>
                            
                            <h3 className="text-2xl font-bold text-slate-900 mb-4">{scenario.title}</h3>
                            <div className="bg-slate-50 p-6 rounded-xl border border-slate-100 mb-6 text-lg leading-relaxed text-slate-700">
                                {scenario.scenario}
                            </div>

                            <div className="flex-1 flex flex-col gap-2">
                                <label className="text-sm font-bold text-slate-500">Your Response / Action:</label>
                                <textarea
                                    className="flex-1 w-full bg-slate-50 border border-slate-200 rounded-xl p-4 text-slate-800 focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
                                    placeholder="Type exactly what you would say or do..."
                                    value={userResponse}
                                    onChange={e => setUserResponse(e.target.value)}
                                />
                            </div>

                            <div className="mt-6 flex justify-end gap-3">
                                <button onClick={() => setView('SELECT')} className="px-6 py-3 text-slate-500 font-bold hover:bg-slate-100 rounded-xl">Cancel</button>
                                <button 
                                    onClick={handleEvaluate}
                                    disabled={!userResponse.trim()}
                                    className="px-8 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 disabled:opacity-50 shadow-lg"
                                >
                                    {t.evaluate}
                                </button>
                            </div>
                        </>
                    ) : null}
                </div>
            )}

            {view === 'RESULT' && evaluation && (
                <div className="flex-1 bg-white border border-slate-200 rounded-2xl shadow-sm p-6 md:p-8 overflow-y-auto animate-slide-up">
                    <div className="flex flex-col md:flex-row gap-8 mb-8">
                        <div className="flex-shrink-0 flex flex-col items-center justify-center p-6 bg-slate-50 rounded-2xl border border-slate-100">
                            <div className={`text-6xl font-black mb-2 ${evaluation.score >= 80 ? 'text-emerald-500' : evaluation.score >= 50 ? 'text-amber-500' : 'text-rose-500'}`}>
                                {evaluation.score}
                            </div>
                            <div className="text-xs font-bold text-slate-400 uppercase tracking-widest">Effectiveness Score</div>
                        </div>
                        <div className="flex-1">
                            <h3 className="text-xl font-bold text-slate-900 mb-2">AI Analysis</h3>
                            <p className="text-slate-600 leading-relaxed">{evaluation.feedback}</p>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                        <div className="bg-emerald-50 p-6 rounded-xl border border-emerald-100">
                            <h4 className="flex items-center gap-2 font-bold text-emerald-800 mb-4">
                                <CheckCircle size={20} /> Strengths
                            </h4>
                            <ul className="space-y-2">
                                {evaluation.strengths.map((s, i) => (
                                    <li key={i} className="text-emerald-700 text-sm">• {s}</li>
                                ))}
                            </ul>
                        </div>
                        <div className="bg-rose-50 p-6 rounded-xl border border-rose-100">
                            <h4 className="flex items-center gap-2 font-bold text-rose-800 mb-4">
                                <AlertTriangle size={20} /> Improvements
                            </h4>
                            <ul className="space-y-2">
                                {evaluation.improvements.map((s, i) => (
                                    <li key={i} className="text-rose-700 text-sm">• {s}</li>
                                ))}
                            </ul>
                        </div>
                    </div>

                    <div className="bg-indigo-50 p-6 rounded-xl border border-indigo-100 mb-8">
                        <h4 className="font-bold text-indigo-900 mb-2">Master Level Example</h4>
                        <div className="bg-white p-4 rounded-lg border border-indigo-100 text-slate-700 italic">
                            "{evaluation.betterExample}"
                        </div>
                    </div>

                    <div className="flex justify-center">
                        <button 
                            onClick={() => setView('SELECT')}
                            className="bg-slate-900 text-white px-8 py-3 rounded-xl font-bold hover:bg-slate-800 shadow-lg flex items-center gap-2"
                        >
                            Try Another Scenario <ArrowRight size={18} />
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};
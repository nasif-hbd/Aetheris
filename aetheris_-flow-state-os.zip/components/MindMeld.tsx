
import React, { useEffect, useRef, useState } from 'react';
import { Mic, MicOff, Zap, Activity } from 'lucide-react';
import { LiveSession } from '../services/geminiService';
import { ConnectionStatus, AppProps } from '../types';
import { PERSONAS, TRANSLATIONS, LANGUAGE_PROMPT_NAMES } from '../constants';

export const MindMeld: React.FC<AppProps> = ({ stats, updateStats, language }) => {
  const t = TRANSLATIONS[language];
  const [status, setStatus] = useState<ConnectionStatus>(ConnectionStatus.DISCONNECTED);
  const [selectedPersonaId, setSelectedPersonaId] = useState(PERSONAS[0].id);
  const sessionRef = useRef<LiveSession | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();
  const startTimeRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      stopSession();
    };
  }, []);

  const stopSession = () => {
      if (sessionRef.current) sessionRef.current.disconnect();
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
      
      if (startTimeRef.current) {
          const durationMinutes = Math.ceil((Date.now() - startTimeRef.current) / 60000);
          updateStats({
              minutesDebated: stats.minutesDebated + durationMinutes,
              sessionsCompleted: stats.sessionsCompleted + 1
          });
          startTimeRef.current = null;
      }
      
      sessionRef.current = null;
      setStatus(ConnectionStatus.DISCONNECTED);
  };

  const visualize = () => {
      const canvas = canvasRef.current;
      const session = sessionRef.current;
      if (!canvas || !session || !session.inputAnalyser || !session.outputAnalyser) return;

      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const inputBufferLength = session.inputAnalyser.frequencyBinCount;
      const inputDataArray = new Uint8Array(inputBufferLength);
      const outputBufferLength = session.outputAnalyser.frequencyBinCount;
      const outputDataArray = new Uint8Array(outputBufferLength);

      const draw = () => {
          animationRef.current = requestAnimationFrame(draw);
          session.inputAnalyser!.getByteFrequencyData(inputDataArray);
          session.outputAnalyser!.getByteFrequencyData(outputDataArray);

          ctx.fillStyle = 'rgba(255, 255, 255, 0.25)'; 
          ctx.fillRect(0, 0, canvas.width, canvas.height);

          const barWidth = (canvas.width / inputBufferLength) * 2.5;
          let x = 0;

          for (let i = 0; i < inputBufferLength; i++) {
              const val = Math.max(inputDataArray[i], outputDataArray[i]);
              const r = 100 - (val / 2);
              const g = 50;
              const b = 255 - (val / 3);

              ctx.fillStyle = `rgb(${r},${g},${b})`;
              const barHeight = (val / 255) * canvas.height;
              ctx.fillRect(x, (canvas.height - barHeight) / 2, barWidth, barHeight);
              x += barWidth + 1;
          }
      };
      draw();
  };

  const toggleConnection = async () => {
    if (status === ConnectionStatus.CONNECTED || status === ConnectionStatus.CONNECTING) {
      stopSession();
    } else {
      const persona = PERSONAS.find(p => p.id === selectedPersonaId) || PERSONAS[0];
      sessionRef.current = new LiveSession();
      
      // Look up the full English name of the language (e.g. 'bn' -> 'Bengali')
      const langName = LANGUAGE_PROMPT_NAMES[language];
      
      // Explicitly instruct the model to speak the target language.
      const langInstruction = ` IMPORTANT: You are speaking to a user who prefers ${langName}. You MUST converse strictly in ${langName} unless asked to translate.`;
      
      await sessionRef.current.connect({
          systemInstruction: persona.systemInstruction + langInstruction,
          voiceName: persona.voiceName,
          onStatusChange: (newStatus) => {
              setStatus(newStatus as ConnectionStatus);
              if (newStatus === ConnectionStatus.CONNECTED) {
                  startTimeRef.current = Date.now();
                  visualize();
              }
          }
      });
    }
  };

  const activePersona = PERSONAS.find(p => p.id === selectedPersonaId);

  return (
    <div className="h-full flex flex-col md:flex-row gap-6 relative overflow-hidden">
      <div className="w-full md:w-80 bg-white border border-slate-200 rounded-2xl p-4 overflow-y-auto z-10 flex-shrink-0 shadow-sm max-h-[30vh] md:max-h-full">
         <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
            <Zap className="text-amber-500" size={20} /> {t.selectPersona}
         </h3>
         <div className="space-y-3">
             {PERSONAS.map(persona => (
                 <button
                    key={persona.id}
                    onClick={() => status === ConnectionStatus.DISCONNECTED && setSelectedPersonaId(persona.id)}
                    disabled={status !== ConnectionStatus.DISCONNECTED}
                    className={`w-full p-4 rounded-xl text-left transition-all border ${
                        selectedPersonaId === persona.id 
                            ? `bg-slate-50 border-${persona.color.split('-')[1]}-500 ring-1 ring-${persona.color.split('-')[1]}-500 shadow-md` 
                            : 'bg-white border-slate-200 hover:bg-slate-50 hover:border-slate-300'
                    }`}
                 >
                     <div className={`font-bold ${selectedPersonaId === persona.id ? 'text-slate-900' : 'text-slate-700'}`}>{persona.name}</div>
                     <div className="text-xs text-slate-500 uppercase tracking-wider mb-1 font-semibold">{persona.role}</div>
                     <div className="text-xs text-slate-500 leading-tight hidden md:block">{persona.description}</div>
                 </button>
             ))}
         </div>
      </div>

      <div className="flex-1 relative bg-white border border-slate-200 rounded-2xl overflow-hidden flex flex-col items-center justify-center p-6 shadow-sm min-h-[400px]">
          <canvas 
            ref={canvasRef} 
            width={800} 
            height={400} 
            className="absolute inset-0 w-full h-full opacity-40 pointer-events-none"
          />

          <div className="z-10 text-center space-y-8 max-w-lg">
             <div>
                 <div className={`inline-block px-3 py-1 rounded-full text-xs font-bold tracking-wider mb-5 bg-gradient-to-r ${activePersona?.color} text-white shadow-md`}>
                     CURRENT MODE: {activePersona?.role.toUpperCase()}
                 </div>
                 <h2 className="text-3xl md:text-5xl font-bold text-slate-900 tracking-tight mb-4">
                    {status === ConnectionStatus.CONNECTED ? t.liveLink : t.initLink}
                 </h2>
                 <p className="text-slate-500 text-lg">
                    {status === ConnectionStatus.CONNECTED ? t.listening : t.connectToStart}
                 </p>
             </div>

             <div className="relative inline-block group">
                {status === ConnectionStatus.CONNECTED && (
                    <div className="absolute inset-0 bg-red-500 rounded-full blur-xl opacity-20 animate-pulse"></div>
                )}
                <button
                    onClick={toggleConnection}
                    className={`
                    relative w-24 h-24 md:w-32 md:h-32 rounded-full flex items-center justify-center transition-all duration-300 shadow-lg
                    ${status === ConnectionStatus.CONNECTED 
                        ? 'bg-white text-red-500 border-4 border-red-500 hover:bg-red-50' 
                        : status === ConnectionStatus.CONNECTING
                        ? 'bg-white text-amber-500 border-4 border-amber-500 animate-pulse'
                        : 'bg-slate-900 text-white border-4 border-slate-900 hover:scale-105 hover:shadow-xl'}
                    `}
                >
                    {status === ConnectionStatus.CONNECTED ? (
                    <MicOff size={40} />
                    ) : status === ConnectionStatus.CONNECTING ? (
                    <Activity className="animate-spin" />
                    ) : (
                    <Mic size={40} />
                    )}
                </button>
             </div>

             <div className="h-6 text-sm font-mono tracking-widest text-slate-400 font-bold">
                 {status === ConnectionStatus.CONNECTED && "TRANSMITTING DATA..."}
             </div>
          </div>
      </div>
    </div>
  );
};

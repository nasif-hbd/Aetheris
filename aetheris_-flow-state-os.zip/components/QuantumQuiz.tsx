
import React, { useState, useEffect, useRef } from 'react';
import { Brain, CheckCircle, XCircle, ChevronRight, Trophy, RefreshCw, Loader2, Award, Clock, PlusCircle } from 'lucide-react';
import { generateQuiz } from '../services/geminiService';
import { QuizQuestion, AppProps } from '../types';
import { TRANSLATIONS } from '../constants';

export const QuantumQuiz: React.FC<AppProps> = ({ stats, updateStats, language }) => {
    const t = TRANSLATIONS[language];
    const [topic, setTopic] = useState('');
    const [questions, setQuestions] = useState<QuizQuestion[]>([]);
    const [loading, setLoading] = useState(false);
    const [currentIndex, setCurrentIndex] = useState(0);
    const [sessionScore, setSessionScore] = useState(0);
    const [showResult, setShowResult] = useState(false);
    const [selectedOption, setSelectedOption] = useState<number | null>(null);
    const [isAnswered, setIsAnswered] = useState(false);
    const scrollRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (isAnswered) {
             setTimeout(() => scrollRef.current?.scrollTo({ top: 9999, behavior: 'smooth' }), 100);
        }
    }, [isAnswered]);

    const loadQuestions = async (append: boolean = false) => {
        if (!topic) return;
        setLoading(true);
        if (!append) {
            setQuestions([]);
            setSessionScore(0);
            setCurrentIndex(0);
            setShowResult(false);
            setIsAnswered(false);
            setSelectedOption(null);
        }
        
        try {
            const data = await generateQuiz(topic, language);
            if (append) {
                setQuestions(prev => [...prev, ...data]);
                setShowResult(false); // Go back to quiz view
                // currentIndex is already at the end of previous set, so it points to next
            } else {
                setQuestions(data);
            }
        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };

    const handleAnswer = (index: number) => {
        if (isAnswered) return;
        setSelectedOption(index);
        setIsAnswered(true);
        if (index === questions[currentIndex].correctIndex) {
            setSessionScore(prev => prev + 100);
        }
    };

    const nextQuestion = () => {
        if (currentIndex < questions.length - 1) {
            setCurrentIndex(prev => prev + 1);
            setIsAnswered(false);
            setSelectedOption(null);
        } else {
            setShowResult(true);
            updateStats({ quizScore: stats.quizScore + sessionScore });
        }
    };

    if (questions.length === 0 && !loading) {
        return (
            <div className="h-full flex flex-col items-center justify-center p-6 animate-slide-up">
                <div className="w-full max-w-md text-center">
                    <div className="w-20 h-20 bg-indigo-50 rounded-3xl flex items-center justify-center mx-auto mb-6 text-indigo-600">
                        <Brain size={40} />
                    </div>
                    <h2 className="text-3xl font-bold text-slate-900 mb-3">{t.quizTitle}</h2>
                    <p className="text-slate-500 mb-8">{t.quizDesc}</p>
                    <div className="bg-white p-2 rounded-2xl shadow-lg border border-slate-100 flex gap-2">
                        <input 
                            value={topic}
                            onChange={(e) => setTopic(e.target.value)}
                            placeholder={t.startTopic}
                            className="flex-1 bg-transparent border-none outline-none px-4 text-slate-900 font-medium"
                            onKeyDown={(e) => e.key === 'Enter' && loadQuestions(false)}
                        />
                        <button onClick={() => loadQuestions(false)} disabled={!topic} className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-indigo-700 transition-colors disabled:opacity-50">
                            Start
                        </button>
                    </div>
                </div>
            </div>
        );
    }

    if (loading) {
        return (
            <div className="h-full flex flex-col items-center justify-center animate-slide-up">
                <Loader2 className="w-12 h-12 text-indigo-600 animate-spin mb-4" />
                <p className="text-slate-500 font-bold tracking-wide">{t.constructing}</p>
            </div>
        );
    }

    if (showResult) {
        return (
            <div className="h-full flex flex-col items-center justify-center p-6 animate-slide-up">
                <div className="bg-white p-10 rounded-3xl shadow-xl border border-slate-100 text-center max-w-sm w-full">
                    <Trophy className="w-20 h-20 text-yellow-400 mx-auto mb-6" />
                    <div className="text-5xl font-black text-slate-900 mb-2">{sessionScore}</div>
                    <div className="text-slate-400 font-bold uppercase tracking-widest text-xs mb-8">Total XP Earned</div>
                    <div className="space-y-3">
                        <button 
                            onClick={() => loadQuestions(true)} 
                            className="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2"
                        >
                            <PlusCircle size={18} /> {t.addMoreQ}
                        </button>
                        <button 
                            onClick={() => setQuestions([])} 
                            className="w-full bg-slate-100 text-slate-600 py-3 rounded-xl font-bold hover:bg-slate-200 transition-colors"
                        >
                            {t.finish}
                        </button>
                    </div>
                </div>
            </div>
        );
    }

    const currentQ = questions[currentIndex];

    return (
        <div className="h-[calc(100vh-140px)] md:h-full flex flex-col animate-slide-up max-w-2xl mx-auto w-full">
             <div className="flex items-center justify-between mb-6">
                 <div className="text-slate-400 text-xs font-bold uppercase">Question {currentIndex + 1} / {questions.length}</div>
                 <div className="bg-indigo-50 text-indigo-700 px-3 py-1 rounded-full text-xs font-bold">
                     {sessionScore} XP
                 </div>
             </div>

             <div className="flex-1 overflow-y-auto no-scrollbar relative rounded-3xl bg-white border border-slate-200 shadow-sm" ref={scrollRef}>
                 <div className="p-6 md:p-8 pb-32">
                     <h3 className="text-xl md:text-2xl font-bold text-slate-900 leading-snug mb-8">
                         {currentQ.question}
                     </h3>

                     <div className="space-y-3">
                         {currentQ.options.map((opt, idx) => {
                             let stateClass = "border-slate-200 hover:bg-slate-50";
                             if (isAnswered) {
                                 if (idx === currentQ.correctIndex) stateClass = "bg-emerald-50 border-emerald-500 text-emerald-700";
                                 else if (idx === selectedOption) stateClass = "bg-rose-50 border-rose-500 text-rose-700";
                                 else stateClass = "opacity-50 grayscale";
                             }
                             return (
                                 <button
                                    key={idx}
                                    onClick={() => handleAnswer(idx)}
                                    disabled={isAnswered}
                                    className={`w-full p-4 rounded-xl border-2 text-left font-medium transition-all ${stateClass} ${selectedOption === idx && !isAnswered ? 'border-indigo-500 bg-indigo-50 text-indigo-700' : ''}`}
                                 >
                                     {opt}
                                 </button>
                             );
                         })}
                     </div>

                     {isAnswered && (
                         <div className="mt-8 p-5 bg-slate-50 rounded-2xl border border-slate-100 animate-slide-up">
                             <div className="text-xs font-bold text-slate-400 uppercase mb-2">Insight</div>
                             <p className="text-slate-700 text-sm leading-relaxed">{currentQ.explanation}</p>
                         </div>
                     )}
                 </div>
             </div>

             {isAnswered && (
                 <div className="absolute bottom-4 left-0 w-full px-4 md:px-0">
                     <button onClick={nextQuestion} className="w-full bg-slate-900 text-white py-4 rounded-2xl font-bold shadow-xl hover:bg-slate-800 transition-all flex items-center justify-center gap-2">
                         {currentIndex === questions.length - 1 ? "Finish" : "Next Question"} <ChevronRight size={18} />
                     </button>
                 </div>
             )}
        </div>
    );
};
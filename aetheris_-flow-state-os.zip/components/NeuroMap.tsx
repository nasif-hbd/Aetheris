
import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as d3 from 'd3';
import { generateConceptMap } from '../services/geminiService';
import { getGraphData, saveGraphData } from '../services/storageService';
import { GraphData, Node, Link, AppProps } from '../types';
import { Search, Loader2, Plus, Maximize, ZoomIn, Pause, Play, RefreshCw } from 'lucide-react';
import { TRANSLATIONS } from '../constants';

export const NeuroMap: React.FC<AppProps> = ({ stats, updateStats, language }) => {
  const t = TRANSLATIONS[language];
  const svgRef = useRef<SVGSVGElement>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);
  
  const [data, setData] = useState<GraphData>(() => getGraphData());
  const [topic, setTopic] = useState('');
  const [loading, setLoading] = useState(false);
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  const [isFrozen, setIsFrozen] = useState(false);

  const simulationRef = useRef<d3.Simulation<Node, Link> | null>(null);

  useEffect(() => {
    if (data.nodes.length > 0) saveGraphData(data);
  }, [data]);

  const handleSearch = async (newTopic: string = topic, expandFromNodeId?: string) => {
    if (!newTopic) return;
    setLoading(true);
    setSelectedNode(null);

    try {
      const existingIds = data.nodes.map(n => n.id);
      const newData = await generateConceptMap(newTopic, expandFromNodeId ? existingIds : [], language);
      
      let updatedData = { ...data };
      const newUniqueNodes = newData.nodes.filter(n => !existingIds.includes(n.id));
      
      if (expandFromNodeId) {
          const newLinks = newData.nodes.map(n => ({ source: expandFromNodeId, target: n.id }));
          updatedData = {
              nodes: [...data.nodes, ...newUniqueNodes],
              links: [...data.links, ...newData.links, ...newLinks]
          };
      } else {
          updatedData = {
            nodes: [...data.nodes, ...newUniqueNodes],
            links: [...data.links, ...newData.links]
          };
      }
      
      setData(updatedData);
      updateStats({ nodesExplored: updatedData.nodes.length });
      setIsFrozen(false); // Unfreeze on new data
    } catch (error) {
      console.error(error);
      alert("Failed to expand map.");
    } finally {
      setLoading(false);
    }
  };

  const renderGraph = useCallback(() => {
    if (!svgRef.current || !wrapperRef.current) return;
    const width = wrapperRef.current.clientWidth;
    const height = wrapperRef.current.clientHeight;
    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove(); 

    // Create gradient definition
    const defs = svg.append("defs");
    const gradient = defs.append("radialGradient")
        .attr("id", "nodeGradient")
        .attr("cx", "50%")
        .attr("cy", "50%")
        .attr("r", "50%");
    gradient.append("stop").attr("offset", "0%").attr("stop-color", "#818cf8");
    gradient.append("stop").attr("offset", "100%").attr("stop-color", "#6366f1");

    if (!simulationRef.current) {
        simulationRef.current = d3.forceSimulation<Node, Link>()
            .force("link", d3.forceLink<Node, Link>().id(d => d.id).distance(120))
            .force("charge", d3.forceManyBody().strength(-300))
            .force("center", d3.forceCenter(width / 2, height / 2))
            .force("collide", d3.forceCollide(50).strength(0.7));
    }

    const simulation = simulationRef.current;
    
    // Update data while preserving x/y if possible
    const nodes = data.nodes.map(d => {
        const old = simulation.nodes().find(n => n.id === d.id);
        if (old) {
            d.x = old.x;
            d.y = old.y;
        }
        return d;
    });
    
    // We must re-map links to node objects for D3
    const links = data.links.map(d => ({ 
        source: typeof d.source === 'object' ? (d.source as any).id : d.source,
        target: typeof d.target === 'object' ? (d.target as any).id : d.target
    }));

    simulation.nodes(nodes);
    (simulation.force("link") as d3.ForceLink<Node, Link>).links(links);
    simulation.alpha(1).restart();
    
    if (isFrozen) simulation.stop();

    const g = svg.append("g");
    const zoom = d3.zoom<SVGSVGElement, unknown>()
        .scaleExtent([0.1, 4])
        .on("zoom", (event) => g.attr("transform", event.transform));
    svg.call(zoom);

    const link = g.append("g").selectAll("line")
        .data(links).join("line")
        .attr("stroke", "#cbd5e1")
        .attr("stroke-width", 2)
        .attr("stroke-opacity", 0.6);

    const node = g.append("g").selectAll("circle")
        .data(nodes).join("circle")
        .attr("r", (d: any) => d.group === 1 ? 28 : 18)
        .attr("fill", (d: any) => d.group === 1 ? "url(#nodeGradient)" : "#fff")
        .attr("stroke", (d: any) => d.group === 1 ? "#4f46e5" : "#6366f1")
        .attr("stroke-width", (d: any) => d.group === 1 ? 0 : 3)
        .attr("cursor", "pointer")
        .style("filter", "drop-shadow(0px 4px 6px rgba(0,0,0,0.1))")
        .call((d3.drag<SVGCircleElement, Node>() as any)
            .on("start", (e: any) => {
                if (!e.active && !isFrozen) simulation.alphaTarget(0.3).restart();
                e.subject.fx = e.subject.x; e.subject.fy = e.subject.y;
            })
            .on("drag", (e: any) => { e.subject.fx = e.x; e.subject.fy = e.y; })
            .on("end", (e: any) => {
                if (!e.active && !isFrozen) simulation.alphaTarget(0);
                e.subject.fx = null; e.subject.fy = null;
            }))
        .on("click", (event, d: any) => {
             event.stopPropagation();
             const original = data.nodes.find(n => n.id === d.id);
             setSelectedNode(original || d);
        });

    const label = g.append("g").selectAll("text")
        .data(nodes).join("text")
        .text((d: any) => d.id)
        .attr("font-size", (d: any) => d.group === 1 ? "12px" : "11px")
        .attr("fill", "#1e293b")
        .attr("text-anchor", "middle")
        .attr("dy", (d: any) => d.group === 1 ? 45 : 35)
        .attr("font-weight", (d: any) => d.group === 1 ? "800" : "600")
        .style("pointer-events", "none")
        .style("text-shadow", "0 2px 4px white, 0 2px 4px white");

    simulation.on("tick", () => {
        link.attr("x1", (d: any) => d.source.x).attr("y1", (d: any) => d.source.y)
            .attr("x2", (d: any) => d.target.x).attr("y2", (d: any) => d.target.y);
        node.attr("cx", (d: any) => d.x).attr("cy", (d: any) => d.y);
        label.attr("x", (d: any) => d.x).attr("y", (d: any) => d.y);
    });
  }, [data, isFrozen]);

  useEffect(() => {
    setTimeout(renderGraph, 100);
    window.addEventListener('resize', renderGraph);
    return () => window.removeEventListener('resize', renderGraph);
  }, [renderGraph]);

  const toggleFreeze = () => {
      setIsFrozen(!isFrozen);
      if (simulationRef.current) {
          if (!isFrozen) simulationRef.current.stop();
          else simulationRef.current.restart();
      }
  };

  const handleReset = () => {
      setData({ nodes: [], links: [] });
      setTopic('');
  };

  return (
    <div className="h-[calc(100vh-140px)] md:h-full flex flex-col relative animate-slide-up">
      {/* Search Bar Floating */}
      <div className="absolute top-4 left-4 right-4 md:left-6 md:w-96 z-10">
          <div className="bg-white/90 backdrop-blur-md p-2 rounded-2xl shadow-lg border border-slate-200 flex gap-2">
              <input
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder={data.nodes.length === 0 ? "Enter topic to map..." : "Add concept..."}
                  className="flex-1 bg-transparent border-none outline-none px-3 text-slate-900 font-medium placeholder:text-slate-400"
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              />
              <button 
                onClick={() => handleSearch()}
                disabled={loading || !topic}
                className="bg-indigo-600 text-white p-2.5 rounded-xl hover:bg-indigo-700 transition-all disabled:opacity-50"
              >
                  {loading ? <Loader2 size={18} className="animate-spin" /> : <Search size={18} />}
              </button>
          </div>
      </div>

      {/* Graph Area */}
      <div ref={wrapperRef} className="flex-1 bg-slate-50 border border-slate-200 rounded-3xl overflow-hidden relative shadow-inner">
          <svg ref={svgRef} className="w-full h-full touch-none" />
          
          {/* Controls */}
          <div className="absolute bottom-4 right-4 flex flex-col gap-2">
              <button 
                className={`bg-white p-2 rounded-xl shadow-md border hover:border-indigo-300 transition-colors ${isFrozen ? 'text-rose-500 border-rose-200' : 'text-slate-600 border-slate-100'}`}
                onClick={toggleFreeze}
                title={isFrozen ? "Unfreeze Layout" : "Freeze Layout"}
              >
                  {isFrozen ? <Play size={20} fill="currentColor" /> : <Pause size={20} fill="currentColor" />}
              </button>
              <button className="bg-white p-2 rounded-xl shadow-md border border-slate-100 text-slate-600 hover:text-indigo-600 hover:border-indigo-300 transition-colors" onClick={() => {
                   d3.select(svgRef.current).transition().duration(750).call(
                       d3.zoom().transform as any, d3.zoomIdentity
                   );
              }}>
                  <Maximize size={20} />
              </button>
              {data.nodes.length > 0 && (
                <button 
                    className="bg-white p-2 rounded-xl shadow-md border border-slate-100 text-slate-600 hover:text-rose-600 hover:border-rose-300 transition-colors" 
                    onClick={() => { if(confirm("Clear current map?")) handleReset(); }}
                    title="Clear Map"
                >
                    <RefreshCw size={20} />
                </button>
              )}
          </div>

          {/* Node Detail Popup */}
          {selectedNode && (
             <div className="absolute bottom-4 left-4 right-4 md:left-4 md:right-auto md:w-80 bg-white p-5 rounded-2xl shadow-xl border border-slate-100 animate-slide-up z-20">
                 <div className="flex justify-between items-start mb-2">
                     <h3 className="font-bold text-lg text-slate-900">{selectedNode.id}</h3>
                     <button onClick={() => setSelectedNode(null)} className="text-slate-400 hover:text-slate-600">×</button>
                 </div>
                 <p className="text-sm text-slate-600 mb-4">{selectedNode.desc || "A key concept in this domain."}</p>
                 <button 
                   onClick={() => handleSearch(selectedNode.id, selectedNode.id)}
                   className="w-full bg-indigo-50 text-indigo-700 font-bold py-2.5 rounded-xl hover:bg-indigo-100 transition-colors flex items-center justify-center gap-2"
                 >
                     <Plus size={16} /> Expand Node
                 </button>
             </div>
          )}
      </div>
    </div>
  );
};


import React, { useState, useEffect } from 'react';
import { generateMetaphorImage } from '../services/geminiService';
import { getImageGallery, saveGeneratedImage, deleteImageFromGallery } from '../services/storageService';
import { Eye, Loader2, Sparkles, Download, Clock, Trash2, Palette, AlertCircle, Monitor, Zap, Maximize } from 'lucide-react';
import { AppProps, SavedImage } from '../types';
import { TRANSLATIONS, IMAGE_STYLES, IMAGE_MODELS } from '../constants';

export const VisionLab: React.FC<AppProps> = ({ language }) => {
  const t = TRANSLATIONS[language];
  const [prompt, setPrompt] = useState('');
  const [selectedStyle, setSelectedStyle] = useState('cinematic');
  const [selectedModelId, setSelectedModelId] = useState(IMAGE_MODELS[0].id);
  
  const [loading, setLoading] = useState(false);
  const [upscaling, setUpscaling] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeImage, setActiveImage] = useState<{ imageUrl: string, explanation: string } | null>(null);
  const [gallery, setGallery] = useState<SavedImage[]>([]);

  // Load gallery on mount
  useEffect(() => {
      setGallery(getImageGallery());
  }, []);

  const handleGenerate = async () => {
    if (!prompt) return;
    setLoading(true);
    setError(null);
    setActiveImage(null); // Clear previous to show loading state
    
    try {
      const data = await generateMetaphorImage(prompt, language, selectedStyle, selectedModelId);
      
      if (!data.imageUrl) throw new Error("API returned no image data");

      setActiveImage(data);

      // Save to local storage
      const newSavedImage: SavedImage = {
          id: Date.now().toString(),
          imageUrl: data.imageUrl,
          prompt: prompt,
          explanation: data.explanation,
          timestamp: Date.now(),
          style: selectedStyle,
          modelUsed: IMAGE_MODELS.find(m => m.id === selectedModelId)?.name
      };
      saveGeneratedImage(newSavedImage);
      
      // Update local state immediately
      setGallery(prev => [newSavedImage, ...prev]);

    } catch (e: any) {
      console.error(e);
      setError(e.message || "Failed to generate image. Try a simpler prompt.");
    } finally {
      setLoading(false);
    }
  };

  const handleUpscale = async () => {
    if (!activeImage || !prompt) return;
    
    // Force use of the HD Pro model
    const HD_MODEL_ID = 'gemini-3-pro-image-preview';
    const hdModelName = IMAGE_MODELS.find(m => m.id === HD_MODEL_ID)?.name || 'Aetheris HD Pro';

    setUpscaling(true);
    setError(null);

    try {
        // We reuse the generate function but force the HD model ID
        const data = await generateMetaphorImage(prompt, language, selectedStyle, HD_MODEL_ID);

        if (!data.imageUrl) throw new Error("Upscale failed");

        setActiveImage(data);
        setSelectedModelId(HD_MODEL_ID); // Switch UI to reflect we are now using Pro

        // Save the upscaled version
        const newSavedImage: SavedImage = {
            id: Date.now().toString(),
            imageUrl: data.imageUrl,
            prompt: prompt,
            explanation: data.explanation, // Keep original explanation or get new one
            timestamp: Date.now(),
            style: selectedStyle,
            modelUsed: hdModelName
        };
        saveGeneratedImage(newSavedImage);
        setGallery(prev => [newSavedImage, ...prev]);

    } catch (e: any) {
        console.error(e);
        setError("Upscale failed. Please try again.");
    } finally {
        setUpscaling(false);
    }
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
      e.stopPropagation();
      if(window.confirm("Delete this memory?")) {
          deleteImageFromGallery(id);
          setGallery(prev => prev.filter(img => img.id !== id));
          if (activeImage && gallery.find(i => i.id === id)?.imageUrl === activeImage.imageUrl) {
              setActiveImage(null);
          }
      }
  };

  const loadFromGallery = (img: SavedImage) => {
      setActiveImage({ imageUrl: img.imageUrl, explanation: img.explanation });
      setPrompt(img.prompt);
      if (img.style) setSelectedStyle(img.style);
      if (img.modelUsed) {
          const m = IMAGE_MODELS.find(im => im.name === img.modelUsed);
          if (m) setSelectedModelId(m.id);
      }
  };

  return (
    <div className="h-full flex flex-col gap-6 overflow-y-auto">
      <div className="flex flex-col lg:flex-row gap-6 min-h-[500px]">
        {/* Input Section */}
        <div className="flex-1 flex flex-col space-y-6">
            <div>
            <h2 className="text-3xl font-bold text-slate-900 mb-2">{t.visualGen}</h2>
            <p className="text-slate-500 text-lg">
                {t.visualDesc}
            </p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-5">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">{t.conceptLabel}</label>
                  <textarea
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                      placeholder="e.g. 'The feeling of deja vu' or 'Schrodinger's Cat'"
                      className="w-full h-24 bg-slate-50 border border-slate-200 text-slate-800 p-4 rounded-xl focus:ring-2 focus:ring-pink-500 focus:bg-white outline-none resize-none transition-all placeholder:text-slate-400"
                  />
                </div>
                
                {/* Render Engine Selection */}
                <div>
                   <label className="block text-sm font-bold text-slate-700 mb-2">Render Engine</label>
                   <div className="grid grid-cols-2 gap-3">
                       {IMAGE_MODELS.map(model => (
                           <button
                             key={model.id}
                             onClick={() => setSelectedModelId(model.id)}
                             className={`p-3 rounded-xl border flex items-center gap-3 transition-all ${
                                 selectedModelId === model.id 
                                 ? 'bg-indigo-50 border-indigo-500 text-indigo-700 ring-1 ring-indigo-500' 
                                 : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                             }`}
                           >
                               <div className={`w-8 h-8 rounded-full flex items-center justify-center ${model.isPro ? 'bg-indigo-200' : 'bg-amber-100'}`}>
                                  {model.isPro ? <Monitor size={16} className="text-indigo-700"/> : <Zap size={16} className="text-amber-600"/>}
                               </div>
                               <div className="text-left">
                                   <div className="font-bold text-xs">{model.name}</div>
                                   <div className="text-[10px] opacity-70">{model.isPro ? 'HD Quality' : 'Fast'}</div>
                               </div>
                           </button>
                       ))}
                   </div>
                </div>

                <div>
                   <label className="block text-sm font-bold text-slate-700 mb-2">{t.styleLabel}</label>
                   <div className="flex gap-2 flex-wrap">
                      {IMAGE_STYLES.map(style => (
                          <button
                            key={style.id}
                            onClick={() => setSelectedStyle(style.id)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${
                                selectedStyle === style.id 
                                ? 'bg-pink-50 border-pink-500 text-pink-700' 
                                : 'bg-white border-slate-200 text-slate-500 hover:border-slate-400'
                            }`}
                          >
                              {style.label}
                          </button>
                      ))}
                   </div>
                </div>

                <button
                    onClick={handleGenerate}
                    disabled={loading || upscaling || !prompt}
                    className="w-full bg-pink-600 hover:bg-pink-700 disabled:opacity-50 text-white p-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-md hover:shadow-lg"
                >
                    {loading ? <Loader2 className="animate-spin" /> : <Sparkles />}
                    {t.generateBtn}
                </button>
            </div>

            {activeImage && !error && !loading && !upscaling && (
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm animate-fade-in">
                    <h3 className="text-lg font-bold text-slate-900 mb-2">{t.aiInsight}</h3>
                    <p className="text-slate-600 italic leading-relaxed">"{activeImage.explanation}"</p>
                </div>
            )}
        </div>

        {/* Preview Area */}
        <div className="flex-1 bg-white rounded-2xl border border-slate-200 flex items-center justify-center p-4 shadow-inner relative overflow-hidden min-h-[400px]">
            {!activeImage && !loading && !error && !upscaling && (
                <div className="absolute inset-0 bg-[radial-gradient(#e2e8f0_1px,transparent_1px)] [background-size:16px_16px] opacity-50"></div>
            )}
            
            {loading || upscaling ? (
            <div className="flex flex-col items-center space-y-4 text-pink-600">
                <Loader2 className="w-12 h-12 animate-spin" />
                <span className="text-sm font-bold animate-pulse tracking-widest">
                    {upscaling ? "UPSCALING TO HD PRO..." : `RENDERING ${selectedStyle.toUpperCase()}...`}
                </span>
            </div>
            ) : error ? (
                <div className="text-center max-w-xs animate-fade-in">
                    <div className="w-16 h-16 bg-rose-50 rounded-full flex items-center justify-center mx-auto mb-4 text-rose-500">
                        <AlertCircle size={32} />
                    </div>
                    <p className="text-slate-900 font-bold mb-2">Generation Failed</p>
                    <p className="text-slate-500 text-sm">{error}</p>
                </div>
            ) : activeImage ? (
            <div className="relative group w-full h-full flex flex-col animate-fade-in justify-center">
                <img 
                    src={activeImage.imageUrl} 
                    alt="Generated Visualization" 
                    className="w-full h-full object-contain rounded-lg shadow-xl"
                />
                
                {/* Actions Overlay */}
                <div className="absolute top-4 right-4 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-all z-10">
                    <button 
                        onClick={handleUpscale}
                        disabled={selectedModelId === 'gemini-3-pro-image-preview'}
                        className="bg-white hover:bg-indigo-50 text-slate-900 hover:text-indigo-600 p-3 rounded-full shadow-lg cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                        title="Upscale with HD Pro"
                    >
                        <Maximize size={20} />
                    </button>
                    <a 
                        href={activeImage.imageUrl} 
                        download={`visionlab-${Date.now()}.png`}
                        className="bg-white hover:bg-slate-100 text-slate-900 p-3 rounded-full shadow-lg cursor-pointer transition-all"
                        title="Download"
                    >
                        <Download size={20} />
                    </a>
                </div>

                <div className="absolute bottom-4 left-4 right-4 text-center">
                    <span className="bg-black/50 backdrop-blur-md text-white px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider">
                        Generated with {gallery.find(i => i.imageUrl === activeImage.imageUrl)?.modelUsed || 'AI Vision'}
                    </span>
                </div>
            </div>
            ) : (
            <div className="text-center text-slate-400 relative z-10">
                <Eye className="w-16 h-16 mx-auto mb-4 opacity-30" />
                <p className="font-medium">Visual output will appear here</p>
            </div>
            )}
        </div>
      </div>

      {/* Gallery Section */}
      {gallery.length > 0 && (
          <div className="mt-8 pb-8">
              <h3 className="text-xl font-bold text-slate-800 mb-4 flex items-center gap-2">
                  <Clock className="text-slate-400" size={20}/> Memory Gallery
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
                  {gallery.map(img => (
                      <div 
                        key={img.id} 
                        onClick={() => loadFromGallery(img)}
                        className={`relative group rounded-xl overflow-hidden cursor-pointer border-2 transition-all ${activeImage?.imageUrl === img.imageUrl ? 'border-pink-500 shadow-md ring-2 ring-pink-200' : 'border-slate-200 hover:border-pink-300'}`}
                      >
                          <img src={img.imageUrl} alt={img.prompt} className="w-full h-32 object-cover" />
                          <div className="absolute bottom-0 left-0 w-full bg-slate-900/80 backdrop-blur-sm p-2">
                              <p className="text-[10px] text-white truncate font-medium">{img.prompt}</p>
                          </div>
                          <div className="absolute top-1 left-1">
                               {img.modelUsed?.includes('Pro') && (
                                   <span className="bg-indigo-600 text-[8px] text-white px-1.5 py-0.5 rounded font-bold uppercase">HD</span>
                               )}
                          </div>
                          <button 
                            onClick={(e) => handleDelete(img.id, e)}
                            className="absolute top-1 right-1 bg-white/90 p-1.5 rounded-full text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-white"
                          >
                              <Trash2 size={14} />
                          </button>
                      </div>
                  ))}
              </div>
          </div>
      )}
    </div>
  );
};
